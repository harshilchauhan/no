// const employeeService = require('../Service/employee.service')
import * as  employeeService from '../Service/employee.service'
// const Employee = require('../Model/employee.model')
import Employee from '../Model/employee.model'
// const comparePassword = require('../Auth/compare_password')
// const {generateToken, generateRefreshToken, verifyToken} = require('../Auth/jwt_helper')
import {generateToken, generateRefreshToken, verifyToken} from '../Auth/jwt_helper'
import createError from 'http-errors'
// const createError = require('http-errors')
// const {sendVerificationMail} = require('../Auth/email_sender')
import sendVerificationMail from '../Auth/email_sender'
// const bcrypt = require('bcrypt')
import bcrypt from 'bcrypt'
// const jwt = require('jsonwebtoken')
import jwt from 'jsonwebtoken'
import { Request,Response } from 'express'
import dotenv from 'dotenv'
dotenv.config()
import {CustomRequest} from '../types/types'

const access_token_secret = process.env.access_token_secret as any

// interface CustomRequest extends Request {
//     companyPayload:any,
//     refreshPayload:any
// }


const createEmployee = async(req:Request,res:Response)=>{
    try {
        const custReq = req as CustomRequest
        if (custReq.companyPayload?.designation !== 'ADMIN') {
             res.status(403).send('Access denied.');
             return 
          }
          console.log('payload:',custReq.companyPayload)
        const {firstname,lastname,email,password,designation,reportsTo} = req.body
        const newEmployee = await employeeService.addEmployee({ firstname, lastname, email, password, designation, reportsTo, company: custReq.companyPayload.company })
        res.status(200).json({newEmployee:newEmployee,message:'new employee created..'})
    } catch (error:any) {
        res.status(500).json({message:'internal server error',error:error.message})  
    }
}

const registerEmployee = async(req:Request,res:Response)=>{
    try {
        const {firstname,lastname,email,password,company,designation} = req.body
        
        const newRegisterEmployee = await employeeService.registerEmployee(
                                    {firstname:firstname,lastname:lastname,email:email,password:password,company:company,designation:designation})
       
        const payLoad = {id:newRegisterEmployee._id,email:email}
        const verificationToken = await generateToken(payLoad)
        const refreshToken = await generateRefreshToken(payLoad)
        newRegisterEmployee.verificationToken = verificationToken;
        await newRegisterEmployee.save()
        const verificationLink = `http://localhost:3000/api/verify-account/${verificationToken}`

        await sendVerificationMail(newRegisterEmployee.firstname,newRegisterEmployee.email,verificationLink)
        res.status(200).json({newRegisterEmployee:newRegisterEmployee,refreshToken:refreshToken, message:'employee register successfully..'})
    } catch (error:any) {
        console.log(error.message)
        res.status(500).json({message:'internal server error'}) 
    }
}
const comparePassword = async(enterpassword:string,storepassword:string)=>{
    try {
        const isValid =  await bcrypt.compare(enterpassword,storepassword)
        console.log(storepassword)
        console.log('enter pass:',enterpassword)
        console.log(isValid)
        return isValid
    } catch (error) {
        throw error
    }
}

const signin = async(req:Request,res:Response)=>{
    try {
        const {email,password} = req.body
        const user = await Employee.findOne({email:email})
        console.log(user)
        // const iscompare = await bcrypt.compare(password,user.password)
        // console.log(iscompare)
        if(!user) throw createError.NotFound(`${email} is not register..`)
        const isMatch = await comparePassword(password,user.password)
        console.log(isMatch)
//         const testHash = await bcrypt.hash('j12', 10); 
// console.log('Hashed Test Password:', testHash);
// const isMatch = await bcrypt.compare('j12', testHash);
// console.log('is match ', isMatch);
        // const isMatch = await user.isValidPassword(password)
        if(!isMatch) throw createError.NotFound('password not match.')
        const payLoad = {id:user.id,email:user.email,designation:user.designation,company:user.company}
        const refreshPayLoad={id:user.id}
        const accessToken = await generateToken(payLoad)
        const refreshToken = await generateRefreshToken(refreshPayLoad)
        

          res.status(200).json({token:accessToken,refreshToken:refreshToken,message:'login successfully..'})
    } catch (error:any) {
        console.log(error.message)
        res.status(500).json({message:'internal server error',error:error.message})
    }
}


const getEmployee = async(req:Request,res:Response)=>{
    try {
        const result = await employeeService.getAllEmployee(req.query)
        // console.log(req.query.firstname)
        res.status(200).json({length:result.length,employee:result})
    } catch (error:any) {
        res.status(500).json({message:'internal server error',error:error.message})
    }
}


const getEmployeeById = async(req:Request,res:Response)=>{
    try {
        const Id=req.params.id
        const result = await employeeService.getEmployeeById(Id)
        res.status(200).json({employee:result})
    } catch (error:any) {
        res.status(500).json({message:'internal server error',error:error.message})
    }
}


const deleteEmployee = async(req:Request,res:Response)=>{
    try {
        const custReq = req as CustomRequest
        if (custReq.companyPayload?.designation !== 'ADMIN') {
             res.status(403).send('Access denied.');
             return
          }
        const Id=req.params.id
        const result = await employeeService.deleteEmployee(Id)
        res.status(200).json({message:'employee deleted.'})
    } catch (error:any) {
        res.status(500).json({message:'internal server error',error:error.message})
    }
}

const employeeHierarchy = async(req:Request,res:Response)=>{
    try {
        const result = await employeeService.employeeHierarchy()
        res.status(200).json({result:result})
    } catch (error:any) {
        res.status(500).json({message:'internal server error',error:error.message})
    }
}

const verifyAccount = async(req:Request,res:Response)=>{

    const token = req.params.token 
    console.log(token)
    const custReq = req as CustomRequest
    if (custReq.companyPayload.designation !== 'ADMIN') {
         res.status(403).send('Access denied.');
         return 
      }
    try {
        const employee = await employeeService.verifyEmployee(token)
        console.log('service employee:',employee)
        if(!employee) {
             res.status(400).json({ message: 'Invalid token or account already verified.' });
             return 
        }
        res.status(200).json({ message: 'Account verified successfully!', employee });
        // res.render('views/email-verified')

    } catch (error:any) {
        res.status(500).json({message:'internal server error',error:error.message})
    }
}

// const updateEmployee = async(req,res)=>{
//     try {
//         const id = req.params.id
//         console.log(id)
//         const employee = await Employee.findById(id);
//         console.log(employee)
//         if(req.companyPayload.id !== id && employee.reportsTo !==req.companyPayload.id){
//             return res.status(403).json({ error: "Unauthorized to update this employee." });
//         }
//         const updateBody = req.body
//         const result = await employeeService.updateEmployeeData(employee.id,updateBody)
//         res.status(200).json({updateCompany:result,message:'employee detail updated..'})
//     } catch (error) {
//         res.status(500).json({message:'internal server error',error:error.message})
//     }
// }


const refreshToken = (req:Request,res:Response)=>{
    try {
        const custReq = req as CustomRequest
        console.log(custReq.refreshPayload)
        const  payLoad= {id:custReq.refreshPayload.id}
   console.log(payLoad)
    const newAccessToken = generateToken({id:payLoad})
    res.status(200).json({accessToken:newAccessToken})
    } catch (error:any) {
        res.status(500).json({message:'internal server error',error:error.message})
    }
   
}

const updatePassword = async(req:Request,res:Response)=>{
    const token = req.params.token
    console.log(token)
    const {password,confirm_password} = req.body
    try {
     
        const decoded:any = jwt.verify(token, access_token_secret);
        const userId = decoded.id; 
        if(password !==confirm_password){
             res.status(400).json({ message: "confirm password is not match" });
             return 
        }
        const user = await Employee.findById(userId);
        console.log(user)
        if(!user)
        {
             res.status(400).json({ message: "User not exists!" });
             return 
        }
        if(user.verified!=true){
             res.status(400).json({ message: "User is not verified.." });
             return
        }
        // const encryptedPassword = await bcrypt.hash(confirm_password, 10);
        const encryptedPassword = confirm_password
       user.password = encryptedPassword 
        await user.save()
        res.status(200).json({message:'password updated successfully..'})
        
    } catch (error:any) {
        res.status(500).json({message:'internal server error',error:error.message})
    }
}




const  updateEmployee = async(req:Request,res:Response)=>{
    try {
        const custReq = req as CustomRequest
        if(custReq.companyPayload.designation !== 'REPORTING_MANAGER'){
             res.status(403).json({message:'not authority to update data '})
             return 
            
        }
        const employeeId = req.params.id
            const employeeToUpdate = await Employee.findById(employeeId)
            const {firstname,lastname,email,password,designation,company,reportsTo} = req.body
            const encryptedPassword = await bcrypt.hash(password, 10);
            console.log(encryptedPassword)
            const result = await Employee.findByIdAndUpdate(employeeToUpdate,{firstname,lastname,email,password:encryptedPassword,designation,company,reportsTo},{new:true})
             res.status(200).json({message:'data updated.. ',result:result})
             return
    } catch (error:any) {
        console.log(error.message)
        res.status(500).json({message:'internal server error',error:error.message})
    }
    
    
}



// module.exports = {
//     createEmployee,
//     registerEmployee,
//     signin,
//     getEmployee,
//     getEmployeeById,
//     deleteEmployee,
//     employeeHierarchy,
//     verifyAccount,
//     updateEmployee,
//     refreshToken,
//     updatePassword
// }

export {
    createEmployee,
    registerEmployee,
    signin,
    getEmployee,
    getEmployeeById,
    deleteEmployee,
    employeeHierarchy,
    verifyAccount,
    updateEmployee,
    refreshToken,
    updatePassword
}

/*
{
      "_id": "65099cfe8d9507797afe0577",
      "user": "Vipul J",
      "role": "CEO",
      "reportees": [
        {
          "_id": "650a901af58cbf4b55db4492",
          "role": "PM",
          "manager": "65099cfe8d9507797afe0577",
          "user": "PM1",
          "reportees": [
            {
              "_id": "650a98971e40ff8cf9d6cb4f",
              "role": "TL",
              "manager": "650a901af58cbf4b55db4492",
              "user": "TL1",
              "reportees": [
                {
                  "_id": "650a9eab963d670eb29b0357",
                  "role": "Dev",
                  "manager": "650a98971e40ff8cf9d6cb4f",
                  "user": "Dev1",
                  "reportees": [
                    {
                      "_id": "650aaa3ab25756af8fea7eff",
                      "role": "Intern",
                      "manager": "650a9eab963d670eb29b0357",
                      "user": "Intern1",
                      "reportees": []
                    }
                  ]
                }
              ]
            },
            {
              "_id": "650a98a31e40ff8cf9d6cb56",
              "role": "TL",
              "manager": "650a901af58cbf4b55db4492",
              "user": "TL2",
              "reportees": [
                {
                  "_id": "650abb0913e4e521d20d0e62",
                  "role": "Sr. Dev",
                  "manager": "650a98a31e40ff8cf9d6cb56",
                  "user": "Sr. Dev1",
                  "reportees": [
                    {
                      "_id": "650abb2913e4e521d20d0e69",
                      "role": "JR. Dev",
                      "manager": "650abb0913e4e521d20d0e62",
                      "user": "JR. Dev1",
                      "reportees": [
                        {
                          "_id": "650abb4213e4e521d20d0e71",
                          "role": "Intern",
                          "manager": "650abb2913e4e521d20d0e69",
                          "user": "Intern1",
                          "reportees": []
                        }
                      ]
                    },
                    {
                      "_id": "650abb2913e4e521d20d0e89",
                      "role": "JR. Dev",
                      "manager": "650abb0913e4e521d20d0e62",
                      "user": "JR. Dev2"
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }



    const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/userHierarchy', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

// Define your User schema
const userSchema = new mongoose.Schema({
    user: String,
    role: String,
    manager: String,
    reportees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
});

const User = mongoose.model('User', userSchema);

// Define API routes
app.get('/users', async (req, res) => {
    const users = await User.find().populate('reportees');
    res.json(users);
});

app.post('/users', async (req, res) => {
    const newUser = new User(req.body);
    await newUser.save();
    res.status(201).json(newUser);
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

    */
