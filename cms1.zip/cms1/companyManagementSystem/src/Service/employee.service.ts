// const employeeDao = require('../DAO/employee.dao')
import * as employeeDao from '../DAO/employee.dao'

const addEmployee = (data:any) => {
    return employeeDao.createEmployee(data)
}

const registerEmployee = (data:any) => {
    return employeeDao.signup(data)
}

const getAllEmployee = (data:any) => {
    return employeeDao.getAllEmployee(data)
}

const getEmployeeById = (id:string) => {
    return employeeDao.getEmployeeById(id)
}
const deleteEmployee = (id:string) => {
    return employeeDao.deleteEmployee(id)
}

const employeeHierarchy = () => {
    return employeeDao.employeeHierarchy()
}

const updateEmployeeData = (id:string,data:any)=>{
    return employeeDao.updateEmployee(id,data)
}


const verifyEmployee =  (token:any) => {
    return employeeDao.verifyEmployee(token)
};

// module.exports = { addEmployee, registerEmployee, getAllEmployee, getEmployeeById, deleteEmployee, employeeHierarchy, verifyEmployee,updateEmployeeData }

export { addEmployee, registerEmployee, getAllEmployee, getEmployeeById, deleteEmployee, employeeHierarchy, verifyEmployee,updateEmployeeData }