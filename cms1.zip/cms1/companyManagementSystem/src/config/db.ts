// const mongoose = require('mongoose')
import mongoose from 'mongoose'
import dotenv from 'dotenv'
dotenv.config()
// require('dotenv').config()
const mongo_uri = process.env.mongo_uri  as string
mongoose.connect(mongo_uri,{dbName:process.env.DB_name})
const db = mongoose.connection
db.on('connected',()=>{
    console.log('db connect.');
    
})
db.on('error',(err)=>{
    console.log(err);

})
db.on('disconnected',()=>{
    console.log('db disconnected..');
})
process.on('SIGINT',async()=>{
    await mongoose.connection.close()
    process.exit(0)
})
// module.exports= db  
export default db