// const Company = require('../Model/company.model')
import  Company from '../Model/company.model'

const companyRegister = (data:any)=>{
    const newCompany = new Company(data)
    return newCompany.save()
}

const updateCompany=(id:any,data:any)=>{
    return Company.findByIdAndUpdate(id,data,{new:true})
}


// export default module.exports = {
//     companyRegister,
//     updateCompany
// } 
export {companyRegister,updateCompany}