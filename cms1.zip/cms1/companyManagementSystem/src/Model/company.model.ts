// "name": "company name", // required, unique, string
//   "email": "company email address", // required, unique, lowercase, string, valid email address
//   "address": {
//     "line1": "address line1", // required, string
//     "line2": "address line2", // string
//     "city": "city name", // required, string
//     "State": "state name", // required, string
//     "country": "country name", // required, string
//     "zip": "postal code" // required, number, 6-digit PIN code
//   },
//   "contact": "mobile number", // required, number, 10 digits valid number
//   "createdBy": "reference of employee collection", // ObjectId



// const mongoose = require('mongoose')
import mongoose from 'mongoose'
import joi from 'joi'
// const joi = require('joi')

const companySchema = new mongoose.Schema({
    name: { type: String, unique: true, required: true },
    email: { type: String, unique: true, required: true },
    address: [{
        line1: { type: String, required: true },
        line2: { type: String },
        city: { type: String, required: true },
        state: { type: String, required: true },
        country: { type: String, required: true },
        zip: {
            type: Number, required: true,
            validate: {
                validator: function (v:any) {
                    return /^\d{6}$/.test(v);
                },
                message: (props:any) => `${props.value} is not a valid 5-digit zip code!`
            }
        }
    }],
    contact: {
        type: Number, required: true, validate: {
            validator: function (v:any) {
                return /^\d{10}$/.test(v);
            },
            message: (props:any) => `${props.value} is not a valid 10-digit mobile number!`
        },
        createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' }
    }

})
// export const Company = mongoose.model('Company', companySchema)
// const Company = mongoose.model('Company', companySchema)
// module.exports = mongoose.model('Company',companySchema)
export default mongoose.model('Company',companySchema)





