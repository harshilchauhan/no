// // const express=require('express')
// import express from 'express'
// const router = express.Router()
// router.use(express.json())
// // const companyController = require('../Controller/company.controller')
// import * as companyController from '../Controller/company.controller'
// // const {verifyToken} = require('../Auth/jwt_helper')
// import {verifyToken} from '../Auth/jwt_helper'

// router.post('/newcompany',companyController.registerCompany)
// router.put('/company/:id',verifyToken,companyController.updateCompany)
// router.patch('/company/:id',verifyToken,companyController.updateCompany)

// module.exports = router


import express from 'express';
const companyrouter = express.Router();
import * as companyController from '../Controller/company.controller';
import { verifyToken } from '../Auth/jwt_helper';
import { CustomRequest } from '../types/types';

companyrouter.use(express.json());

companyrouter.post('/newcompany', companyController.registerCompany);
companyrouter.put('/company/:id', verifyToken,  companyController.updateCompany);
companyrouter.patch('/company/:id', 
    verifyToken,
     companyController.updateCompany);

export default companyrouter;
