import { AnySchema, ValidationError } from 'yup'
import { Request, Response, NextFunction, query } from 'express'

// const  ReqBodyValidate = (schema:AnySchema) => async(req:Request,res:Response,next:NextFunction) =>{
//     try {
//         await schema.validate({
//             body:req.body,
//             query:req.query,
//             params:req.params
//         })
//         next()    
//     } catch (error:any) {
//         return res.status(400).send(error.message)
//     }



// }


const ReqBodyValidate = (schema: AnySchema) => async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        await schema.validate(
            // { 
                 req.body, 
                // params: req.params 
            // }, 
            { abortEarly: false });
        next();
    } catch (error) {
        if (error instanceof ValidationError) {
            res.status(400).json({ message: "Validation error", errors: error.errors });
        } else {
            next(error);
        }
    }
};

export default ReqBodyValidate
