import * as Yup from 'yup';

const companyYupValidationSchema = Yup.object().shape({
    name: Yup.string().required("Company name is required"),
    email: Yup.string()
        .email("Invalid email address")
        .lowercase()
        .required("Company email is required"),
    address: Yup.array()
        .of(
            Yup.object().shape({
                line1: Yup.string().required("Address line1 is required"),
                line2: Yup.string(),
                city: Yup.string().required("City is required"),
                state: Yup.string().required("State is required"),
                country: Yup.string().required("Country is required"),
                zip: Yup.number()
                    .typeError("ZIP code must be a number")
                    .test("len", "ZIP code must be 6 digits", (val: any) => val && val.toString().length === 6)
                    .required("ZIP code is required"),
            })
        ).required('company address is required'),
    contact: Yup.string()
        .matches(/^[0-9]{10}$/, "Contact must be a valid 10-digit number")
        .required("Contact number is required"),
    createdBy: Yup.string()
});

export default companyYupValidationSchema


