const bcrypt = require('bcrypt')

const comparePassword = async(enterpassword,storepassword)=>{
    try {
        const isValid =  await bcrypt.compare(enterpassword,storepassword)
        console.log(storepassword)
        console.log('enter pass:',enterpassword)
        console.log(isValid)
        return isValid
    } catch (error) {
        throw error
    }
}

module.exports = comparePassword