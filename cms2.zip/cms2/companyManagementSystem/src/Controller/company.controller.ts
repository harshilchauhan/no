// const companyService = require('../Service/company.service')
import * as companyService from '../Service/company.service'
import {Request,Response} from 'express'
import {CustomRequest} from '../types/types'
import logger from '../helper/winston_logger'

// interface CustomRequest extends Request {
//     companyPayload:any
// }

const registerCompany = async(req:Request,res:Response)=>{
    try {
        const bodyData = req.body
        const newCompany = await companyService.registerCompany(bodyData)
        logger.info('company register successfully')
        res.status(200).json({newCompany:newCompany,message:'company register successfully'})
    } catch (error) {
        if(error instanceof Error){
            console.log(error)
            logger.error(error.message)
            res.status(500).json({message:'internal server error',error:error.message})
        }
    }
}

const updateCompany = async(req:Request,res:Response)=>{
    try {
        const customReq = req as CustomRequest;
        if (customReq.companyPayload?.designation !== 'ADMIN') {
            logger.warn('access denied')
             res.status(403).send('Access denied.');
             return 
          }
        const Id = req.params.id
        const updateBody = req.body
        const result = await companyService.updateCompany(Id,updateBody)
        res.status(200).json({updateCompany:result,message:'company detail updated..'})
    } catch (error) {
        if(error instanceof Error){
            console.log(error)
            res.status(500).json({message:'internal server error',error:error.message})
        }
        
    }
}

// module.exports = {registerCompany,updateCompany}
export {registerCompany,updateCompany}


