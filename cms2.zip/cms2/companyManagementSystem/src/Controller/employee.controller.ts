import * as employeeService from "../Service/employee.service";
import Employee from "../Model/employee.model";
import {
  generateToken,
  generateRefreshToken,
  verifyToken,
} from "../Auth/jwt_helper";
import createError from "http-errors";
// const createError = require('http-errors')
import sendVerificationMail from "../Auth/email_sender";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { Request, Response } from "express";
import dotenv from "dotenv";
dotenv.config();
import { CustomRequest } from "../types/types";
import logger from "../helper/winston_logger";

const access_token_secret = process.env.access_token_secret as string;

const createEmployee = async (req: Request, res: Response) => {
  try {
    const custReq = req as CustomRequest;
    if (custReq.companyPayload?.designation !== "ADMIN") {
      logger.warn('access denied only admin can access this api')
      res.status(403).send("Access denied.");
      return;
    }
    //   console.log('payload:',custReq.companyPayload)
    const { firstname, lastname, email, password, designation, reportsTo } =
      req.body;
    const newEmployee = await employeeService.addEmployee({
      firstname,
      lastname,
      email,
      password,
      designation,
      reportsTo,
      company: custReq.companyPayload.company,
    });
    logger.info('new employee register successfully')
    res
      .status(200)
      .json({ newEmployee: newEmployee, message: "new employee created.." });
  } catch (error: any) {
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

// const registerEmployee = async(req:Request,res:Response)=>{
//     try {
//         const {firstname,lastname,email,password,company,designation} = req.body

//         const newRegisterEmployee = await employeeService.registerEmployee(
//                                     {firstname:firstname,lastname:lastname,email:email,password:password,company:company,designation:designation})

//         const payLoad = {id:newRegisterEmployee._id,email:email}
//         const verificationToken = await generateToken(payLoad)
//         const refreshToken = await generateRefreshToken(payLoad)
//         newRegisterEmployee.verificationToken = verificationToken;
//         await newRegisterEmployee.save()
//         const verificationLink = `http://localhost:3000/api/verify-account/${verificationToken}`

//         await sendVerificationMail(newRegisterEmployee.firstname,newRegisterEmployee.email,verificationLink)
//         res.status(200).json({newRegisterEmployee:newRegisterEmployee,refreshToken:refreshToken, message:'employee register successfully..'})
//     } catch (error:any) {
//         console.log(error.message)
//         res.status(500).json({message:'internal server error',error:error.message})
//     }
// }

const registerEmployee = async (req: Request, res: Response) => {
  try {
    const { firstname, lastname, email, password, company, designation } =
      req.body;

    const emailExists = await Employee.findOne({ email: email });
    if (emailExists) throw new Error("email already exists..");
    const newRegisterEmployee = await employeeService.registerEmployee({
      firstname: firstname,
      lastname: lastname,
      email: email,
      password: password,
      company: company,
      designation: designation,
    });

    const payLoad = { id: newRegisterEmployee._id, email: email };
    const verificationToken = await generateToken(payLoad);
    const refreshToken = await generateRefreshToken(payLoad);
    newRegisterEmployee.verificationToken = verificationToken;
    await newRegisterEmployee.save();
    const verificationLink = `http://localhost:8888/api/verify-account/${newRegisterEmployee.verificationToken}`;

    await sendVerificationMail(
      newRegisterEmployee.firstname,
      newRegisterEmployee.email,
      verificationLink
    );
    logger.info(`employee registration  successfully.. account verification email is sent to your ${email} address `)
    res
      .status(200)
      .json({
        message: `employee registration  successfully.. account verification email is sent to your ${email} address `,
      });
  } catch (error: any) {
    // console.log(error.message)
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

const getverifyUser = async (req: Request, res: Response) => {
  try {
    const { token } = req.params;
    // const findUserId = await Employee.findById({_id:user_id})
    // console.log(findUserId)

    const employee = await employeeService.verifyEmployee(token);
    // if(!findUserId){
    // res.status(404).json({message:'user not found'})
    // }
    // await Employee.updateOne({_id:user_id},{$set:{verified:true}})
    // res.status(200).json({message:'user verify successfully'})
    res.render("email-verified");
  } catch (error: any) {
    console.log(error.message);
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

const comparePassword = async (
  enterpassword: string,
  storepassword: string
) => {
  try {
    const isValid = await bcrypt.compare(enterpassword, storepassword);
    // console.log(storepassword);
    // console.log("enter pass:", enterpassword);
    // console.log(isValid);
    return isValid;
  } catch (error) {
    throw error;
  }
};

const signin = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const user = await Employee.findOne({ email: email });
    console.log(user);
    if (!user) {
      throw createError.NotFound(`${email} is not register..`);
    }
    const isMatch = await comparePassword(password, user.password);
    console.log(isMatch);
    // const isMatch = await user.isValidPassword(password)
    if (!isMatch) {
      throw createError.NotFound("password not match.");
    }
    const payLoad = {
      id: user.id,
      email: user.email,
      designation: user.designation,
      company: user.company,
    };
    const refreshPayLoad = { id: user.id };
    const accessToken = await generateToken(payLoad);
    const refreshToken = await generateRefreshToken(refreshPayLoad);
    logger.info('login successfully')
    res
      .status(200)
      .json({
        token: accessToken,
        refreshToken: refreshToken,
        message: "login successfully..",
      });
  } catch (error: any) {
    console.log(error.message);
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

const getEmployee = async (req: Request, res: Response) => {
  try {
    const result = await employeeService.getAllEmployee(
      req.query.filter_employee
    );
    // console.log(req.query.keyword)
    res.status(200).json({ length: result.length, employee: result });
  } catch (error: any) {
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

/*const getAllEmployee = async (data: any) => {
    const filters: any = {};

    
    for (const key in data) {
        if (data.hasOwnProperty(key)) {
            
            if (key.startsWith("filter_")) {
            
                const fieldName = key.replace("filter_", "");  
                filters[fieldName] = data[key];
            }
            
        }
    }

    
    const pipeline: any[] = [
        {
            $match: filters 
        },
        
    ];

    
    return Employee.aggregate(pipeline);
}



const getEmployee = async (req: Request, res: Response) => {
    try {
        // Call the service function and pass the query parameters from the request
        const result = await employeeService.getAllEmployee(req.query);

        // Return the response with filtered results
        res.status(200).json({
            length: result.length,
            employee: result
        });
    } catch (error: any) {
        res.status(500).json({ message: 'Internal server error', error: error.message });
    }
}
*/

const getEmployeeById = async (req: Request, res: Response) => {
  try {
    // const {id}=req.params
    const result = await employeeService.getEmployeeById(req.params.id);
    res.status(200).json({ employee: result });
  } catch (error: any) {
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

const deleteEmployee = async (req: Request, res: Response) => {
  try {
    const custReq = req as CustomRequest;
    if (custReq.companyPayload?.designation !== "ADMIN") {
      res.status(403).send("Access denied.");
      return;
    }
    const Id = req.params.id;
    const result = await employeeService.deleteEmployee(Id);
    logger.info('employee deleted.')
    res.status(200).json({ message: "employee deleted." });
  } catch (error: any) {
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

const employeeHierarchy = async (req: Request, res: Response) => {
  try {
    const { company_id } = req.params;
    // console.log(company_id)
    const result = await employeeService.employeeHierarchy(company_id);
    // console.log(result)
    // const filterResult = result.filter((data:any)=>data.company===company_id)
    res.status(200).json({length: result.length, result: result });
  } catch (error: any) {
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

// const verifyAccount = async(req:Request,res:Response)=>{

//     const token = req.params.token
//     console.log(token)
//     const custReq = req as CustomRequest
//     if (custReq.companyPayload.designation !== 'ADMIN') {
//          res.status(403).send('Access denied.');
//          return
//       }
//     try {
//         const employee = await employeeService.verifyEmployee(token)
//         console.log('service employee:',employee)
//         if(!employee) {
//              res.status(400).json({ message: 'Invalid token or account already verified.' });
//              return
//         }
//         res.status(200).json({ message: 'Account verified successfully!', employee });
//         // res.render('email-verified')

//     } catch (error:any) {
//         res.status(500).json({message:'internal server error',error:error.message})
//     }
// }

// const updateEmployee = async(req,res)=>{
//     try {
//         const id = req.params.id
//         console.log(id)
//         const employee = await Employee.findById(id);
//         console.log(employee)
//         if(req.companyPayload.id !== id && employee.reportsTo !==req.companyPayload.id){
//             return res.status(403).json({ error: "Unauthorized to update this employee." });
//         }
//         const updateBody = req.body
//         const result = await employeeService.updateEmployeeData(employee.id,updateBody)
//         res.status(200).json({updateCompany:result,message:'employee detail updated..'})
//     } catch (error) {
//         res.status(500).json({message:'internal server error',error:error.message})
//     }
// }

const refreshToken = (req: Request, res: Response) => {
  try {
    const custReq = req as CustomRequest;
    console.log(custReq.refreshPayload);
    const payLoad = { id: custReq.refreshPayload.id };
    console.log(payLoad);
    const newAccessToken = generateToken({ id: payLoad });
    res.status(200).json({ accessToken: newAccessToken });
  } catch (error: any) {
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

const updatePassword = async (req: Request, res: Response) => {
  const token = req.params.token;
  console.log(token);
  const { password, confirm_password } = req.body;
  try {
    const decoded: any = jwt.verify(token, access_token_secret);
    const userId = decoded.id;
    if (password !== confirm_password) {
      logger.error('confirm password is not match.')
      res.status(400).json({ message: "confirm password is not match" });
      return;
    }
    const user = await Employee.findById(userId);
    console.log(user);
    if (!user) {
      logger.error('user not exists')
      res.status(400).json({ message: "User not exists!" });
      return;
    }
    if (user.verified != true) {
      logger.error('user is not verified.')
      res.status(400).json({ message: "User is not verified.." });
      return;
    }
    // const encryptedPassword = await bcrypt.hash(confirm_password, 10);
    const encryptedPassword = confirm_password;
    user.password = encryptedPassword;
    await user.save();
    logger.info('password updated successfully')
    res.status(200).json({ message: "password updated successfully.." });
  } catch (error: any) {
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

const updateEmployee = async (req: Request, res: Response) => {
  try {
    const custReq = req as CustomRequest;
    if (custReq.companyPayload.designation !== "REPORTING_MANAGER") {
      logger.warn('not authority to update data')
      res.status(403).json({ message: "not authority to update data " });
      return;
    }
    const employeeId = req.params.id;
    const employeeToUpdate = await Employee.findById(employeeId);
    const {
      firstname,
      lastname,
      email,
      password,
      designation,
      company,
      reportsTo,
    } = req.body;
    const encryptedPassword = await bcrypt.hash(password, 10);
    // console.log(encryptedPassword);
    const result = await Employee.findByIdAndUpdate(
      employeeToUpdate,
      {
        firstname,
        lastname,
        email,
        password: encryptedPassword,
        designation,
        company,
        reportsTo,
      },
      { new: true }
    );
    logger.info('password updated.')
    res.status(200).json({ message: "data updated.. ", result: result });
    return;
  } catch (error: any) {
    console.log(error.message);
    logger.error(error.message)
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

// module.exports = {
//     createEmployee,
//     registerEmployee,
//     signin,
//     getEmployee,
//     getEmployeeById,
//     deleteEmployee,
//     employeeHierarchy,
//     verifyAccount,
//     updateEmployee,
//     refreshToken,
//     updatePassword
// }

export {
  createEmployee,
  registerEmployee,
  signin,
  getEmployee,
  getEmployeeById,
  deleteEmployee,
  employeeHierarchy,
  // verifyAccount,
  updateEmployee,
  refreshToken,
  updatePassword,
  getverifyUser,
};
