import Employee from "../Model/employee.model";
import Company from "../Model/company.model";
import mongoose from "mongoose";

const createEmployee = (data: any) => {
  const newEmployee = new Employee(data);
  return newEmployee.save();
};

const signup = (data: any) => {
  const existingCompany = Company.findById(data.company);
  if (!existingCompany) {
    throw new Error("company does not exist..");
  }
  const registerEmployee = new Employee(data);
  return registerEmployee.save();
};

const getAllEmployee = (filter_employee: any) => {
  const filters = {} as any;

  // if (data.designation) {
  //     filters.designation = { $regex: data.designation, $options:"i" }
  // }
  // if (data.firstname) {
  //     filters.firstname = { $regex: data.firstname, $options:"i" }
  // }
  // if (data.email) {
  //     filters.email = { $regex: data.email, $options:"i" }
  // }
  // console.log('data',filter_employee)

  return Employee.find({
    $and: [
      {
        $or: [
          { firstname: { $regex: filter_employee, $options: "i" } },
          { lastname: { $regex: filter_employee, $options: "i" } },
          {
            email: { $regex: filter_employee, $options: "i" },
          },
          {
            designation: { $regex: filter_employee, $options: "i" },
          },
        ],
      },
    ],
  }).select("-__v -password");
  // return  Employee.find(filters);
  // return Employee.find(data)

  // return Employee.find().where('firstname').equals(data)
};

const getEmployeeById = (id: string) => {
  return Employee.findById(id);
};

const deleteEmployee = (id: string) => {
  return Employee.findByIdAndDelete(id);
};

// const employeeHierarchy = (company_id:string) => {
//     // return Employee.find().populate('company', 'name email -_id').populate('reportsTo','-_id  firstname lastname email designation  ')
//     // return Employee.find({company:company_id}).populate('company', 'name email -_id').populate('reportsTo','-_id  firstname lastname email designation  ')

//    return Employee.aggregate([
//         {
//             $match:{company:company_id}
//         },
//         {
//             $graphLookup: {
//                 from: "employees",
//                 startWith: "$_id",
//                 connectFromField: "_id",
//                 connectToField: "reportsTo",
//                 as: "company",
//                 depthField: "level",
//             }
//         },

//         {
//             $project: {
//                 _id: 1,
//                 firstname: 1,
//                 lastname:1,
//                 email: 1,
//                 designation:1,
//                 company: {
//                     name:1,
//                     email:1,
//                     level: 1
//                 },
//                 reportsTo:{
//                     firstname:1,
//                     lastname:1 ,
//                     email:1,
//                     designation:1
//                 }
//             }
//         },
//     ])

// }

const employeeHierarchy = (company_id: any) => {
  // return Employee.aggregate([

  // { $match: { company:  mongoose.Types.ObjectId.createFromHexString(company_id) } },
  //     { $match: { designation: 'ADMIN' } },
  //     {
  //         $graphLookup: {
  //             from: 'employees',
  //             startWith: '$company',
  //             connectFromField: '_id',
  //             connectToField: 'company',
  //             as: 'reports',
  //             depthField: 'level',
  //         }
  //     },
  //     // {
  //     //     $addFields: {
  //     //         reports: {
  //     //             $map: {
  //     //                 input: '$reports',
  //     //                 as: 'reports',
  //     //                 in: {
  //     //                     $mergeObjects: [
  //     //                         '$$reports',
  //     //                         {
  //     //                             sortOrder: {
  //     //                                 $indexOfArray: [
  //     //                                     ['ADMIN', 'REPORTING_MANAGER', 'DEVELOPER'],
  //     //                                     '$$reports.designation'
  //     //                                 ]
  //     //                             }
  //     //                         }
  //     //                     ]
  //     //                 }
  //     //             }
  //     //         }
  //     //     }
  //     // },
  //     {
  //         $project: {
  //             firstname: 1,
  //             lastname: 1,
  //             email: 1,
  //             designation: 1,
  //             reports: 1
  //             // {
  //             //     $filter: {
  //             //         input: '$reports',
  //             //         as: 'reports',
  //             //         cond: { $eq: ['$$reports.designation', 'REPORTING_MANAGER'] }
  //             //     }
  //             // }
  //         }
  //     },
  //     { $sort: { 'reports.sortOrder': 1 } },
  // ]);

  const result: any = Employee.aggregate([
    {
      $match: {
        company: mongoose.Types.ObjectId.createFromHexString(company_id),
        designation: "ADMIN"
      },
    },
    // { $match: { designation: "ADMIN" } },
    {
      $graphLookup: {
        from: "employees",
        startWith: "$company",
        connectFromField: "reportsTo",
        connectToField: "company",
        as: "reports",
        depthField: "level",
      },
    },

    {
      $project: {
        _id: 1,
        firstname: 1,
        lastname: 1,
        email: 1,
        designation: 1,
        company: 1,
        
        reports: {
          _id: 1,
          firstname: 1,
          lastname: 1,
          email: 1,
          designation: 1,
          company: 1,
          reportsTo:1,
        //   reports:{
        //     _id: 1,
        //     firstname: 1,
        //     lastname: 1,
        //     email: 1,
        //     designation: 1,
        //     company: 1,
        //     level:1
        //   },
          level: 1,
        },
      },
    },
  ]);

  


  return result
  };

  /*
    db.employees.aggregate([{ $match: { company: ObjectId("6719d226fa7fa2b56902c740")}},{$match:{designation:'ADMIN'}},
{
            $graphLookup: {
                from: 'employees', 
                startWith: '$company', 
                connectFromField: '_id',
                connectToField: 'reportsTo',
                as: 'reports',
                depthField: 'level', 
            }
},
{
    $unwind: {
      path: "$reports",
      preserveNullAndEmptyArrays: true
    }
  },
{ $sort: { "reports.level": -1 } },
{
    $group: {
      _id: "$_id",
      firstname: { $first: "$firstname" },
      lastname: { $first: "$lastname" },
			email:{$first:"$email"},
			designation:{$first:"$designation"},
			company:{$first:"$company"},
      reports: { $push: "$reports" }
    }
  },
])*/


const verifyEmployee = async (token: string) => {
  const employee: any = await Employee.findOne({ verificationToken: token });
  console.log(employee);
  // if (!employee.verified) {
  //     return null;
  // }

  // employee.verified = true;
  await Employee.updateOne(
    { verificationToken: token },
    { $set: { verified: true, verificationToken: null } }
  );
  // await Employee.
  // employee.verificationToken = null;
  // await employee.save();

  return employee;
};

const updateEmployee = (id: string, data: any) => {
  return Employee.findByIdAndUpdate(id, data, { new: true });
};




export {
  signup,
  createEmployee,
  getAllEmployee,
  getEmployeeById,
  deleteEmployee,
  employeeHierarchy,
  verifyEmployee,
  updateEmployee,
};


//   console.log("result[0]:", result);
//   const hierarchy = createHierarchy(result[0]);

