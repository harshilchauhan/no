import  express  from "express"
const employeerouter = express.Router()
employeerouter.use(express.json())
import * as  employeeController from '../Controller/employee.controller'
import {verifyToken,verifyRefreshToken} from '../Auth/jwt_helper'
import ReqBodyValidate from "../Auth/validateRequest"
import {employeeYupValidationSchema,employeeLoginYupValidationSchema,queryValidator} from "../Auth/employee_schema_validate"






employeerouter.post('/sign-up',ReqBodyValidate(employeeYupValidationSchema),employeeController.registerEmployee)
employeerouter.post('/sign-in',ReqBodyValidate(employeeLoginYupValidationSchema),employeeController.signin)
employeerouter.post('/employee',verifyToken,employeeController.createEmployee)
employeerouter.get('/employee',employeeController.getEmployee)
employeerouter.get('/employee/:id',ReqBodyValidate(queryValidator),employeeController.getEmployeeById)
employeerouter.delete('/employee/:id',verifyToken,employeeController.deleteEmployee)
employeerouter.get('/employee+hierarchy/:company_id',employeeController.employeeHierarchy)
// employeerouter.get('/verify-account/:token',verifyToken,employeeController.verifyAccount)
employeerouter.get('/verify-account/:token',employeeController.getverifyUser)
employeerouter.put('/employee/:id',verifyToken,employeeController.updateEmployee)
employeerouter.get('/refresh-token',verifyRefreshToken,employeeController.refreshToken)
employeerouter.post('/on-board/:token',employeeController.updatePassword)


// module.exports = router
export default employeerouter





















/*

app.put('/api/company', authenticateJWT, async (req, res) => {
    if (req.user.designation !== 'ADMIN') {
        return res.sendStatus(403);
    }

    try {
        const company = await Company.findByIdAndUpdate(req.body.id, req.body, { new: true });
        res.json(company);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update Company API (Admin Only, PATCH)
app.patch('/api/company', authenticateJWT, async (req, res) => {
    if (req.user.designation !== 'ADMIN') {
        return res.sendStatus(403);
    }

    try {
        const company = await Company.findByIdAndUpdate(req.body.id, req.body, { new: true });
        res.json(company);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
*/






