// const companyDao = require('../DAO/company.dao')
import * as  companyDao from '../DAO/company.dao'


const registerCompany = (data:string)=>{
    return companyDao.companyRegister(data)
}   

const updateCompany = (id:any,data:any) =>{
    return companyDao.updateCompany(id,data)
}

// module.exports={
//     registerCompany,
//     updateCompany
// }
export {updateCompany,registerCompany}