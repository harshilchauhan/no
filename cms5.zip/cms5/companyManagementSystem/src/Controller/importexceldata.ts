// import { parentPort, workerData } from 'worker_threads';
const { parentPort, workerData } = require("worker_threads");
// import xlsx from 'xlsx';
const xlsx = require("xlsx");
// import Employee from "../Model/employee.model";
const Employee = require("../Model/employee.model");
// const Employee = require("../Model/employee.model");

const chunk_size = 25;

async function processExcel(filePath: any) {
  try {
    const workBook = xlsx.readFile(filePath);
    const sheetName = workBook.SheetNames[0];
    const data = xlsx.utils.sheet_to_json(workBook.Sheets[sheetName]);

    for (let i = 0; i < data.length; i += chunk_size) {
      const chunk = data.slice(i, i + chunk_size).map((record: any) => ({
        id: record.Employee_Id,
        firstname: record.First_Name,
        lastname: record.Last_Name,
        email: record.Email,
        password: record.Password,
        designation: record.Designation,
        company: record.Company || null,
        reportsTo: record.ReportsTo || null,
      }));
      await Employee.insertMany(chunk);
    }

    parentPort?.postMessage({ success: true });
  } catch (error: any) {
    console.error(error.message);
    parentPort?.postMessage({ success: false, error: error.message });
  }
}

processExcel(workerData.filePath);

/*

export const importExcel = async (req: Request, res: Response) => {
  const filename = req.file?.originalname;
  const filePath = path.join(__dirname, "../public/upload/", filename);

  // Spawn a new worker for handling the file import
  const worker = new Worker(path.join(__dirname, 'importWorker.js'), {
    workerData: { filePath }
  });

  // Listen for messages from the worker
  worker.on('message', (message) => {
    if (message.success) {
      res.status(200).json({ success: true, msg: "Excel imported successfully" });
    } else {
      res.status(500).json({ error: message.error });
    }
  });

  
  worker.on('error', (error) => {
    res.status(500).json({ error: error.message });
  });

  // Re-spawn the worker if it exits unexpectedly
  worker.on('exit', (code) => {
    if (code !== 0) {
      console.error(`Worker stopped with exit code ${code}`);
      // Re-spawn worker logic could go here
    }
  });
};*/
