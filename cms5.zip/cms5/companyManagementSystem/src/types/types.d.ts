import { Request } from 'express';

// export interface CompanyPayload {
//     designation: string;
//     // Add any other properties that are part of your payload
// }

// export interface CustomRequest extends Request {
//     companyPayload: CompanyPayload;
// }
export interface CustomRequest extends Request {
    companyPayload:any,
    refreshPayload:any
}