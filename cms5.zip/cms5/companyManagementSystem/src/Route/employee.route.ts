import express from "express";
const employeerouter = express.Router();
employeerouter.use(express.json());
// import * as  employeeController from '../Controller/employee.controller'
import {
  registerEmployee,
  signin,
  createEmployee,
  getEmployee,
  getEmployeeById,
  deleteEmployee,
  employeeHierarchy,
  getverifyUser,
  updateEmployee,
  refreshToken,
  updatePassword,
  excelData,
  sendOtp,
  verifyOtp,
  exportPdf,
  importExcel,
  importExcelData,
} from "../Controller/employee.controller";
import { verifyToken, verifyRefreshToken } from "../Auth/jwt_helper";
import {
  ReqBodyValidate,
  ReqParamValidate,
  validateParams,
} from "../Auth/validateRequest";
import {
  employeeYupValidationSchema,
  employeeLoginYupValidationSchema,
  paramsValidationSchema,
  employeeSendOtpYupValidator,
  employeeVerifyOtpYupValidator,
  getEmployeeByIdYupValidator,
  AddNewEmployeeYupValidator,
  UpdateEmployeeYupValidator,
} from "../Auth/employee_schema_validate";
import multer from "multer";
import path from "path";

/**
 * @route POST /sign-up
 * @returns  The created employee object
 * @throws  If registration fails
 */
employeerouter.post(
  "/sign-up",
  ReqBodyValidate(employeeYupValidationSchema),
  registerEmployee
);
/**
 * @route POST /sign-in
 * @returns  The signed-in user object
 * @throws  If sign-in fails
 */

employeerouter.post(
  "/sign-in",
  ReqBodyValidate(employeeLoginYupValidationSchema),
  signin
);
/**
 * @route POST /employee
 * @returns  -Add New employees
 */
employeerouter.post(
  "/employee",
  ReqBodyValidate(AddNewEmployeeYupValidator),
  verifyToken,
  createEmployee
);
/**
 * @route GET /employee
 * @returns  -List of employees
 * @throws  If fetching employees fails
 */

employeerouter.get("/employee", getEmployee);
/**
 * @route GET /employee/:id
 * @param  id - The employee ID
 * @returns  Employee record
 */
employeerouter.get(
  "/employee/:id",
  validateParams(getEmployeeByIdYupValidator),
  getEmployeeById
);

/**
 * @route DELETE /employee/:id
 * @param  id - The employee ID
 * @returns  The employee Deleted
 */

employeerouter.delete(
  "/employee/:id",
  validateParams(getEmployeeByIdYupValidator),
  verifyToken,
  deleteEmployee
);

/**
 * @route GET /employee-hierarchy/:company_id
 * @param  company_id - The company ID
 * @returns  Employee hierarchy
 */
employeerouter.get(
  "/employee-hierarchy/:company_id",
  ReqParamValidate(paramsValidationSchema),
  employeeHierarchy
);
/**
 * @route GET /verify-account/:token
 * @param  token - The verification token
 * @returns  Verification result
 */
// employeerouter.get('/verify-account/:token',verifyToken,employeeController.verifyAccount)
employeerouter.get("/verify-account/:token", getverifyUser);
/**
 * @route PUT /employee/:id
 * @param  id - The employee ID
 * @returns  The updated employee object
 */
employeerouter.put(
  "/employee/:id",
  ReqBodyValidate(UpdateEmployeeYupValidator),
  verifyToken,
  updateEmployee
);
/**
 * @route GET /refresh-token
 * @returns  New access token
 */
employeerouter.get("/refresh-token", verifyRefreshToken, refreshToken);
/**
 * @route POST /update-password/:token
 * @param token - the verification token
 * @returns  password updated.
 */
employeerouter.post("/update-password/:token", updatePassword);

employeerouter.get("/downloadexcel", excelData);

employeerouter.get("/employee-hierarchy/", (req, res) => {
  res.status(400).json({ message: "Company ID is required" });
});
employeerouter.post(
  "/send-otp",
  ReqBodyValidate(employeeSendOtpYupValidator),
  sendOtp
);
employeerouter.post(
  "/verify-otp",
  ReqBodyValidate(employeeVerifyOtpYupValidator),
  verifyOtp
);

employeerouter.get("/export-pdf", exportPdf);
employeerouter.get("/import-excel", importExcel);

// employeerouter.use(express.static(path.resolve(__dirname, "public")));
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null,  "src/public/upload");
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage: storage });

employeerouter.post("/import", upload.single("multerfile"), importExcel);

// module.exports = router
export default employeerouter;
