import mongoose from "mongoose";

const employeeSchema = new mongoose.Schema(
  {
    firstname: { type: String,  },
    lastname: { type: String },
    email: {
      type: String,
      lowercase: true,
      validate: {
        validator: function (v: any) {
          return /^\S+@\S+\.\S+$/.test(v);
        },
        message: (props: any) => `${props.value} is not a valid email!`,
      },
    },
    password: { type: String },
    designation: {
      type: String,
      enum: ["ADMIN", "REPORTING_MANAGER", "DEVELOPER"],
      default: "DEVELOPER",
    },
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
    },
    verified: { type: Boolean, default: false },
    reportsTo: { type: mongoose.Schema.Types.ObjectId, ref: "Employee" },
    verificationToken: { type: String },
  },
  { versionKey: false }
);

export default mongoose.model("emp", employeeSchema);
