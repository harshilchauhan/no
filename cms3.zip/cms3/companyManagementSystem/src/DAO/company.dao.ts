// const Company = require('../Model/company.model')
import Company from "../Model/company.model";

/**
 * Registers a new company.
 *
 * @param {string} data - The data to create a new company. This should be a string representation of the company data.
 * @returns {Promise} A promise that resolves to the newly created company document.
 */

const companyRegister = (data: string): Promise<any> => {
  const newCompany = new Company(data);
  return newCompany.save();
};

/**
 * Updates an existing company by its ID.
 *
 * @param {any} id - The ID of the company to update.
 * @param {any} data - The data to update the company with.
 * @returns {Promise} A promise that resolves to the updated company document.
 */
const updateCompany = (id: any, data: any): Promise<any> => {
  return Company.findByIdAndUpdate(id, data, { new: true });
};

// export default module.exports = {
//     companyRegister,
//     updateCompany
// }
export { companyRegister, updateCompany };
