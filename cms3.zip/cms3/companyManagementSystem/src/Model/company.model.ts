// "name": "company name", // required, unique, string
//   "email": "company email address", // required, unique, lowercase, string, valid email address
//   "address": {
//     "line1": "address line1", // required, string
//     "line2": "address line2", // string
//     "city": "city name", // required, string
//     "State": "state name", // required, string
//     "country": "country name", // required, string
//     "zip": "postal code" // required, number, 6-digit PIN code
//   },
//   "contact": "mobile number", // required, number, 10 digits valid number
//   "createdBy": "reference of employee collection", // ObjectId



// const mongoose = require('mongoose')
import mongoose from 'mongoose'


import {AnySchema, number, object, string} from 'yup'

const companySchema = new mongoose.Schema({
    name: { type: String, unique: true, required: true },
    email: { type: String, unique: true, required: true },
    address: [{
        line1: { type: String, required: true },
        line2: { type: String },
        city: { type: String, required: true },
        state: { type: String, required: true },
        country: { type: String, required: true },
        zip: {
            type: Number, required: true,
            validate: {
                validator: function (v:any) {
                    return /^\d{6}$/.test(v);
                },
                message: (props:any) => `${props.value} is not a valid 5-digit zip code!`
            }
        }
    }],
    contact: {
        type: Number, required: true, validate: {
            validator: function (v:any) {
                return /^\d{10}$/.test(v);
            },
            message: (props:any) => `${props.value} is not a valid 10-digit mobile number!`
        },
    },  
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' }

})


// import * as Yup from 'yup';

// const companySchemaYup = Yup.object({
//   name: Yup.string()
//     .required('Company name is required'),
    

//   email: Yup.string()
//     .email('Invalid email format')
//     .required('Email is required'),

//   address: Yup.array().of(
//     Yup.object({
//       line1: Yup.string().required('Address line 1 is required'),
//       line2: Yup.string(),
//       city: Yup.string().required('City is required'),
//       state: Yup.string().required('State is required'),
//       country: Yup.string().required('Country is required'),
//       zip: Yup.number()
//         .required('Zip code is required')
//         .test('validZip', 'Zip code must be a 6-digit number', value => /^\d{6}$/.test(String(value)))
//     })
//   ),

//   contact: Yup.number()
//     .required('Contact number is required')
//     .test('validContact', 'Contact number must be a 10-digit number', value => /^\d{10}$/.test(String(value))),

//   createdBy: Yup.string()
//     .nullable()
// });

// export default companySchemaYup;


// const companySchema = object({
//     body:object({
//         name:string().required(),
//         email:string().email().required(),
//         address:[
//             {
//                 line1:string().required(),
//                 line2:string(),
//                 city:string(),
//                 state:string(),
//                 country:string(),
//                 zip:number()

//             }],
//             contact:number(),
//             createdBy:{type:mongoose.Schema.Types.obj}
//     })
// })
// export const Company = mongoose.model('Company', companySchema)
// const Company = mongoose.model('Company', companySchema)
// module.exports = mongoose.model('Company',companySchema)
export default mongoose.model('Company',companySchema)





