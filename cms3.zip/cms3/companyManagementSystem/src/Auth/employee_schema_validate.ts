import * as Yup from 'yup';

enum designation{
    'ADMIN',
    'REPORTING_MANAGER', 
    'DEVELOPER'
}

const employeeYupValidationSchema = Yup.object().shape({
    
    firstname: Yup.string().required(" first name is required"),
    lastname: Yup.string().required("last name is required"),
    email: Yup.string()
    .email("Invalid email address")
    .lowercase()
    .required("employee email is required"),
    password: Yup.string().required("password is required"),
    designation: Yup.mixed<designation>().oneOf(Object.values(designation) as designation[])
    .required(),
    company: Yup.string().required('company Id is required'),
    verified: Yup.boolean(),
    reportsTo:Yup.string(),
    verificationToken: Yup.string()
})

const employeeLoginYupValidationSchema = Yup.object().shape({
    email:Yup.string()
    .email("Invalid email address")
    .lowercase()
    .required("employee email is required"),
    password:Yup.string().required("password is required"),
})

const paramsValidationSchema = Yup.object().shape({
    company_id: Yup.string().required("ID is required"),    
});
export  {employeeYupValidationSchema,employeeLoginYupValidationSchema,paramsValidationSchema}
