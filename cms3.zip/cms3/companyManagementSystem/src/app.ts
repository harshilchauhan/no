import express,{Request,Response,NextFunction} from "express"
const app = express()
import employeerouter from './Route/employee.route'
import companyrouter from "./Route/company.route"
import winston from "winston"
import expresswinston from 'express-winston'
import createError from 'http-errors'
// const createError = require('http-errors')
import  db from './config/db'
import ejs from 'ejs'
import dotenv from 'dotenv'
dotenv.config()
const database = db
const port = process.env.PORT
import path from "path"
import logger from "./helper/winston_logger"
import morgan from 'morgan'
import ratelimit from "express-rate-limit"

app.set("views", path.join(__dirname, "views"));
app.set('view engine', 'ejs');
// app.use((err:any,req:Request,res:Response,next:NextFunction) => {
//     res.status(500).send('internal server error');
//        logger.error(`${err.status || 500} - ${res.statusMessage} - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`);
//     })

// app.use(expresswinston.logger({
//     transports: [
//         // new winston.transports.Console(),
//         new winston.transports.File({filename:'error.log'}),
//     ],
//     format: winston.format.combine(
//         winston.format.colorize(),
//         winston.format.json(),
//         winston.format.prettyPrint()
//     )
// }));

const limiter = ratelimit({
  windowMs:  60 * 1000, //15 min
  max: 10,
  message: "too many request from this Ip,please try again after 15 min"

})

app.use(morgan('combined', {
    stream: {
      write: (message: string) => {
        logger.info(message.trim());  
      }
    }
  }));
app.use('/api',limiter,employeerouter)
app.use('/api',limiter,companyrouter)






// app.use(async (req:Request, res:Response, next:NextFunction) => {
//     // const error= new Error("not found")
//     // error.status =404
//     next(createError.NotFound())
// })

// app.use((err:any, req:Request, res:Response, next:NextFunction) => {
//     res.status(err.status || 500)
//     res.send({
//         error: {
//             status: err.status || 500,
//             message: err.message
//         }
//     })

// })

app.listen(port,()=>{
    console.log(`server run at ${port} `)
    logger.info(`server run at ${port}`)
})