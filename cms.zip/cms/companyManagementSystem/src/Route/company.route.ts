// const express=require('express')
import express from 'express'
const router = express.Router()
router.use(express.json())
// const companyController = require('../Controller/company.controller')
import * as companyController from '../Controller/company.controller'
// const {verifyToken} = require('../Auth/jwt_helper')
import {verifyToken} from '../Auth/jwt_helper'

router.post('/newcompany',companyController.registerCompany)
router.put('/company/:id',verifyToken,companyController.updateCompany)
router.patch('/company/:id',verifyToken,companyController.updateCompany)

module.exports = router

