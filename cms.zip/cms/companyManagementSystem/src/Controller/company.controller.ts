// const companyService = require('../Service/company.service')
import * as companyService from '../Service/company.service'
import {Request,Response} from 'express'

interface CustomRequest extends Request {
    companyPayload:any
}

const registerCompany = async(req:Request,res:Response)=>{
    try {
        const bodyData = await  req.body
        const newCompany = await companyService.registerCompany(bodyData)
        res.status(200).json({newCompany:newCompany,message:'new company register..'})
    } catch (error) {
        if(error instanceof Error){
            console.log(error)
            res.status(500).json({message:'internal server error',error:error.message})
        }
    }
}

const updateCompany = async(req:Request,res:Response)=>{
    try {
        const customReq = req as CustomRequest;
        if (customReq.companyPayload.designation !== 'ADMIN') {
            return res.status(403).send('Access denied.');
          }
        const Id = req.params.id
        const updateBody = req.body
        const result = await companyService.updateCompany(Id,updateBody)
        res.status(200).json({updateCompany:result,message:'company detail updated..'})
    } catch (error) {
        if(error instanceof Error){
            console.log(error)
            res.status(500).json({message:'internal server error',error:error.message})
        }
        
    }
}

// module.exports = {registerCompany,updateCompany}
export {registerCompany,updateCompany}




/*


import * as companyService from '../Service/company.service';
import { Request, Response } from 'express';

interface CustomRequest extends Request {
    companyPayload: any;
}

const registerCompany = async (req: Request, res: Response): Promise<void> => {
    try {
        const bodyData = req.body;
        const newCompany = await companyService.registerCompany(bodyData);
        res.status(200).json({ newCompany, message: 'New company registered.' });
    } catch (error) {
        if (error instanceof Error) {
            console.log(error);
            res.status(500).json({ message: 'Internal server error', error: error.message });
        }
    }
};

const updateCompany = async (req: CustomRequest, res: Response): Promise<void> => {
    try {
        if (req.companyPayload.designation !== 'ADMIN') {
            return res.status(403).send('Access denied.');
        }
        const id = req.params.id;
        const updateBody = req.body;
        const result = await companyService.updateCompany(id, updateBody);
        res.status(200).json({ updateCompany: result, message: 'Company details updated.' });
    } catch (error) {
        if (error instanceof Error) {
            console.log(error);
            res.status(500).json({ message: 'Internal server error', error: error.message });
        }
    }
};

export { registerCompany, updateCompany };
*/