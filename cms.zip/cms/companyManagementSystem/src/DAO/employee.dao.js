const Employee = require('../Model/employee.model')
const Company = require('../Model/company.model')

const createEmployee = (data) => {
    const newEmployee = new Employee(data)
    return newEmployee.save()
}

const signup = (data) => {
    const existingCompany = Company.findById(data.company)
    if (!existingCompany) {
        throw new Error('company does not exist..');
    }
    const registerEmployee = new Employee(data)
    return registerEmployee.save()

}

const getAllEmployee = (data) => {

    const filters = {};

        if (data.designation) {
            filters.designation = { $regex: new RegExp(data.designation, 'i') }
        }
        if (data.firstname) {
            filters.firstname = { $regex: new RegExp(data.firstname, 'i') }
        }
        if (data.email) {
            filters.email = { $regex: new RegExp(data.email, 'i') }
        }

        return  Employee.find(filters);
    // return Employee.find(data)

    // return Employee.find().where('firstname').equals(data)
}

const getEmployeeById = (id) => {
    return Employee.findById(id)
}

const deleteEmployee = (id) => {
    return Employee.findByIdAndDelete(id)
}

const employeeHierarchy = () => {
    return Employee.find().populate('company', 'name email -_id').populate('reportsTo','-_id  firstname lastname email designation  ')
}


const verifyEmployee = async (token) => {
    const employee = await Employee.findOne({ verificationToken: token });
    if (!employee.verified) {
        return null;
    }
    employee.verified = true;
    employee.verificationToken = null;
    await employee.save();

    return employee;
};

const updateEmployee = (id,data)=>{
    return Employee.findByIdAndUpdate(id,data,{new:true})
}





module.exports = { signup, createEmployee, getAllEmployee, getEmployeeById, deleteEmployee, employeeHierarchy, verifyEmployee,updateEmployee }
