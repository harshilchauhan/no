// const jwt = require('jsonwebtoken')
import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'
import { Request,Response,NextFunction } from 'express'
dotenv.config()
// const createError = require('http-errors')
import createError from 'http-errors'
const access_token_secret=process.env.access_token_secret as string
const refresh_token_secret = process.env.refresh_token_secret as string 

interface CustomRequest extends Request {
    companyPayload:any,
    refreshPayload:any
}

const generateToken = (data:any) => {
    return jwt.sign(data, access_token_secret,{ expiresIn: '30m' })
}

const verifyToken = (req:Request, res:Response, next:NextFunction) => {
    const custReq = req as CustomRequest;
    const authorization = req.headers['authorization']
    if (!authorization) return next(createError.NotFound('token not found'))

    const authHeader = req.headers['authorization'] as string
    const bearertoken = authHeader.split(' ')
    const token = bearertoken[1]
    if(!token) return next(createError.Unauthorized())
    jwt.verify(token, access_token_secret, (err, payload) => {
        if (err) return res.status(401).json({message:'token is expire..'})
            custReq.companyPayload = payload
        next()
    })
}

const generateRefreshToken = (data:any)=>{
    return jwt.sign(data, refresh_token_secret, { expiresIn: '1d' });
}
const verifyRefreshToken = (req:Request, res:Response, next:NextFunction) => {
    const custReq = req as CustomRequest;
    const authorization = req.headers['authorization']
    if (!authorization) return next(createError.NotFound('refresh token not found'))

    const authHeader = req.headers['authorization'] as string
    const bearertoken = authHeader.split(' ')
    const token = bearertoken[1]
    if(!token) return next(createError.Unauthorized())
    jwt.verify(token, refresh_token_secret, (err, payload) => {
        if (err) return res.status(401).json({message:'refresh token is expire..'})
            custReq.refreshPayload = payload
        next()
    })
}


// module.exports = { generateToken, verifyToken,generateRefreshToken,verifyRefreshToken }

export {
    generateToken, 
    verifyToken,
    generateRefreshToken,
    verifyRefreshToken 
}

