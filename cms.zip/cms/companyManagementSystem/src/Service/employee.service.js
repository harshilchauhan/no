const employeeDao = require('../DAO/employee.dao')
const addEmployee = (data) => {
    return employeeDao.createEmployee(data)
}

const registerEmployee = (data) => {
    return employeeDao.signup(data)
}

const getAllEmployee = (data) => {
    return employeeDao.getAllEmployee(data)
}

const getEmployeeById = (id) => {
    return employeeDao.getEmployeeById(id)
}
const deleteEmployee = (id) => {
    return employeeDao.deleteEmployee(id)
}

const employeeHierarchy = () => {
    return employeeDao.employeeHierarchy()
}

const updateEmployeeData = (id,data)=>{
    return employeeDao.updateEmployee(id,data)
}


const verifyEmployee = async (token) => {
    return employeeDao.verifyEmployee(token)
};

module.exports = { addEmployee, registerEmployee, getAllEmployee, getEmployeeById, deleteEmployee, employeeHierarchy, verifyEmployee,updateEmployeeData }