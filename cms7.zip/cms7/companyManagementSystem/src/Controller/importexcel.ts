const { parentPort, isMainThread, workerData } = require("worker_threads");
const xlsx = require("xlsx");
import mongoose from "mongoose";
import Employee from "../Model/employee.model";
import db from "../config/db";
import connectToDatabase from "../config/db";

const chunk_size = 25;

// async function connectToDatabase() {
//   const mongoUri: any = process.env.mongo_uri;
//   const dbName = process.env.DB_name;

//   await mongoose.connect(mongoUri, {
//     dbName: dbName,
//   });
//   console.log("Worker: MongoDB connected successfully");
// }

async function processExcel(fileBuffer: Buffer) {
  try {
    await connectToDatabase();
    const workBook = xlsx.read(fileBuffer, { type: "buffer" });
    if (!workBook.SheetNames || workBook.SheetNames.length === 0) {
      throw new Error("No sheets found in the uploaded file");
    }

    const sheetName = workBook.SheetNames[0];
    const data = xlsx.utils.sheet_to_json(workBook.Sheets[sheetName]);

    // for (let i = 0; i < data.length; i += chunk_size) {
    //   const chunk = data.slice(i, i + chunk_size).map((record: any) => ({
    //     id: record.Employee_Id,
    //     firstname: record.First_Name,
    //     lastname: record.Last_Name,
    //     email: record.Email,
    //     password: record.Password,
    //     designation: record.Designation,
    //     company: record.Company,
    //     reportsTo: record.ReportsTo || null,
    //   }));
    //    await Employee.insertMany(chunk);
    // }
    let i = 0;
    while (i < data.length) {
      const sliceData = data.slice(i, i + chunk_size);
      const chunk = sliceData.map((record: any) => ({
        id: record.Employee_Id,
        firstname: record.First_Name,
        lastname: record.Last_Name,
        email: record.Email,
        password: record.Password,
        designation: record.Designation,
        company: record.Company,
        reportsTo: record.ReportsTo || null,
      }));
       Employee.insertMany(chunk);
      i += chunk_size;
    }

    parentPort?.postMessage({ success: true });
  } catch (error: any) {
    console.log("error:", error.message);
    parentPort?.postMessage({ success: false, error: error.message });
  }
}
processExcel(workerData.fileBuffer);
