import * as Yup from "yup";

enum designation {
  "ADMIN",
  "REPORTING_MANAGER",
  "DEVELOPER",
}

const employeeYupValidationSchema = Yup.object().shape({
  firstname: Yup.string().required(" first name is required"),
  lastname: Yup.string().required("last name is required"),
  email: Yup.string()
    .email("Invalid email address")
    .lowercase()
    .required("employee email is required"),
  password: Yup.string().required("password is required"),
  designation: Yup.mixed<designation>()
    .oneOf(Object.values(designation) as designation[])
    .required(),
  company: Yup.string().required("company Id is required"),
  verified: Yup.boolean(),
  reportsTo: Yup.string(),
  verificationToken: Yup.string(),
});

const employeeLoginYupValidationSchema = Yup.object().shape({
  email: Yup.string()
    .email("Invalid email address")
    .lowercase()
    .required("employee email is required"),
  password: Yup.string().required("password is required"),
});

const paramsValidationSchema = Yup.object().shape({
  company_id: Yup.string().required("ID is required"),
});

const getEmployeeByIdYupValidator = Yup.object().shape({
  id: Yup.string().required("ID is required"),
});

const employeeSendOtpYupValidator = Yup.object().shape({
  email: Yup.string()
    .email("Invalid email address")
    .lowercase()
    .required("employee email is required"),
});

const employeeVerifyOtpYupValidator = Yup.object().shape({
  user_id: Yup.string().required("userID is required"),
  otp: Yup.string().required("otp is required"),
});

const AddNewEmployeeYupValidator = Yup.object().shape({
  firstname: Yup.string().required(" first name is required"),
  lastname: Yup.string().required("last name is required"),
  email: Yup.string()
    .email("Invalid email address")
    .lowercase()
    .required("employee email is required"),
  password: Yup.string().required("password is required"),
  designation: Yup.mixed<designation>()
    .oneOf(Object.values(designation) as designation[])
    .required(),
  reportsTo: Yup.string(),
});

const UpdateEmployeeYupValidator = Yup.object().shape({
  id: Yup.string().required("ID is required"),
  firstname: Yup.string(),
  lastname: Yup.string(),
  email: Yup.string().email("Invalid email address").lowercase(),
  password: Yup.string(),
  designation: Yup.mixed<designation>()
    .oneOf(Object.values(designation) as designation[])
    .required(),
  reportsTo: Yup.string(),
});

export {
  employeeYupValidationSchema,
  employeeLoginYupValidationSchema,
  paramsValidationSchema,
  employeeSendOtpYupValidator,
  employeeVerifyOtpYupValidator,
  getEmployeeByIdYupValidator,
  AddNewEmployeeYupValidator,
  UpdateEmployeeYupValidator
};
