import express from "express";
const companyrouter = express.Router();
import * as companyController from "../Controller/company.controller";
import { verifyToken } from "../Auth/jwt_helper";
import { ReqBodyValidate, ReqParamValidate } from "../Auth/validateRequest";
import {
  companyYupValidationSchema,
  paramsValidationSchema,
} from "../Auth/company_schema_validate";
import { CustomRequest } from "../types/types";

companyrouter.use(express.json());

/**
 * @route POST /api/company
 * @returns New Company Register
 */
companyrouter.post(
  "/company",
  ReqBodyValidate(companyYupValidationSchema),
  companyController.registerCompany
);

/**
 * @route PUT /company/:id
 * @param id -The Company Id
 * @returns Company Record Updated
 */

companyrouter.put("/company/:id", verifyToken, companyController.updateCompany);
/**
 * @route PATCH /company/:id
 * @param id -The Company Id
 * @returns Company Record Updated
 */
companyrouter.patch(
  "/company/:id",
  verifyToken,
  companyController.updateCompany
);

export default companyrouter;
