// const mongoose = require('mongoose')
import mongoose from "mongoose";
import dotenv from "dotenv";
dotenv.config();
// require('dotenv').config()
const mongo_uri = process.env.mongo_uri as string;

// async function connectToDatabase() {
//   await mongoose.connect(mongo_uri, {
//     dbName: process.env.DB_name,
//     // bufferCommands: false,
//     // connectTimeoutMS: 60000,
//   });

//   const db = await mongoose.connection;

//   db.on("connected", () => {
//     console.log("db connect.");
//   });
//   db.on("error", (err) => {
//     console.log(err);
//   });
//   db.on("disconnected", () => {
//     console.log("db disconnected..");
//   });
//   process.on("SIGINT", async () => {
//     await mongoose.connection.close();
//     process.exit(0);
//   });
// }

async function connectToDatabase() {
  try {
    const db = await mongoose.connect(mongo_uri, {
      dbName: process.env.DB_name,
    });

    return db;
  } catch (error) {
    console.error("Failed to connect to the database:", error);
  }
}
const database = mongoose.connection;

database.on("connected", () => {
  console.log("db connected.");
});
database.on("error", (err) => {
  console.error("db connection error:", err);
});
database.on("disconnected", () => {
  console.log("db disconnected.");
});

process.on("SIGINT", async () => {
  await mongoose.connection.close();
  process.exit(0);
});
// module.exports= db
// export default db;
export default connectToDatabase;
