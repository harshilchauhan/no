import Employee from "../Model/employee.model";
import Company from "../Model/company.model";
import mongoose, { model } from "mongoose";

/**
 * register New Employee
 * @param  data - the data to be create a new Employee
 * @returns  - the return  of the created Employee
 */

const createEmployee = (data: any) => {
  const newEmployee = new Employee(data);
  return newEmployee.save();
};
/**
 * signup of the employee
 *
 * @param  data -the data to be registration of  the employee
 * @returns  - the return  of the register the employee
 */

const signup = (data: any) => {
  const existingCompany = Company.findById(data.company);
  if (!existingCompany) {
    throw new Error("company does not exist..");
  }
  const registerEmployee = new Employee(data);
  return registerEmployee.save();
};

/**
 * get all employee and filter employee
 *
 * @param filter_employee  - the filtering  to find the employee data
 * @returns  - the return  of the find the employee data
 */

const getAllEmployee = (filter_employee: any) => {
  const filters = {} as any;

  // if (data.designation) {
  //     filters.designation = { $regex: data.designation, $options:"i" }
  // }
  // if (data.firstname) {
  //     filters.firstname = { $regex: data.firstname, $options:"i" }
  // }
  // if (data.email) {
  //     filters.email = { $regex: data.email, $options:"i" }
  // }
  // console.log('data',filter_employee)

  return Employee.find({
    $and: [
      {
        $or: [
          { firstname: { $regex: filter_employee, $options: "i" } },
          { lastname: { $regex: filter_employee, $options: "i" } },
          {
            email: { $regex: filter_employee, $options: "i" },
          },
          {
            designation: { $regex: filter_employee, $options: "i" },
          },
        ],
      },
    ],
  }).select("-__v -password");
  // return  Employee.find(filters);
  // return Employee.find(data)

  // return Employee.find().where('firstname').equals(data)
};

/**
 * find employee by employeeId
 *
 * @param id - the id of the employee to find particular Employee
 * @returns  - find the Employee by EmployeeId
 */

const getEmployeeById = (id: any) => {
  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new Error("Invalid ID format"); 
  }
  return Employee.findById(id);
};

/**
 * delete employee by employeeId
 *
 * @param id - the id of the employee to be deleted
 * @returns  - delete the Employee by EmployeeId
 */

const deleteEmployee = (id: string) => {
  return Employee.findByIdAndDelete(id);
};

// const employeeHierarchy = (company_id:string) => {
//     // return Employee.find().populate('company', 'name email -_id').populate('reportsTo','-_id  firstname lastname email designation  ')
//     // return Employee.find({company:company_id}).populate('company', 'name email -_id').populate('reportsTo','-_id  firstname lastname email designation  ')

//    return Employee.aggregate([
//         {
//             $match:{company:company_id}
//         },
//         {
//             $graphLookup: {
//                 from: "employees",
//                 startWith: "$_id",
//                 connectFromField: "_id",
//                 connectToField: "reportsTo",
//                 as: "company",
//                 depthField: "level",
//             }
//         },

//         {
//             $project: {
//                 _id: 1,
//                 firstname: 1,
//                 lastname:1,
//                 email: 1,
//                 designation:1,
//                 company: {
//                     name:1,
//                     email:1,
//                     level: 1
//                 },
//                 reportsTo:{
//                     firstname:1,
//                     lastname:1 ,
//                     email:1,
//                     designation:1
//                 }
//             }
//         },
//     ])

// }

/**
 * Employee Hierarchy Company wise
 *
 * @param company_id - id of the company
 * @returns  - return  employee hierarchy company wise
 */

const employeeHierarchy = (company_id: any) => {
  // return Employee.aggregate([

  // { $match: { company:  mongoose.Types.ObjectId.createFromHexString(company_id) } },
  //     { $match: { designation: 'ADMIN' } },
  //     {
  //         $graphLookup: {
  //             from: 'employees',
  //             startWith: '$company',
  //             connectFromField: '_id',
  //             connectToField: 'company',
  //             as: 'reports',
  //             depthField: 'level',
  //         }
  //     },
  //     // {
  //     //     $addFields: {
  //     //         reports: {
  //     //             $map: {
  //     //                 input: '$reports',
  //     //                 as: 'reports',
  //     //                 in: {
  //     //                     $mergeObjects: [
  //     //                         '$$reports',
  //     //                         {
  //     //                             sortOrder: {
  //     //                                 $indexOfArray: [
  //     //                                     ['ADMIN', 'REPORTING_MANAGER', 'DEVELOPER'],
  //     //                                     '$$reports.designation'
  //     //                                 ]
  //     //                             }
  //     //                         }
  //     //                     ]
  //     //                 }
  //     //             }
  //     //         }
  //     //     }
  //     // },
  //     {
  //         $project: {
  //             firstname: 1,
  //             lastname: 1,
  //             email: 1,
  //             designation: 1,
  //             reports: 1
  //             // {
  //             //     $filter: {
  //             //         input: '$reports',
  //             //         as: 'reports',
  //             //         cond: { $eq: ['$$reports.designation', 'REPORTING_MANAGER'] }
  //             //     }
  //             // }
  //         }
  //     },
  //     { $sort: { 'reports.sortOrder': 1 } },
  // ]);

  // const result: any = Employee.aggregate([
  //   // {
  //   //   $match: {
  //   //     company: mongoose.Types.ObjectId.createFromHexString(company_id),
  //   //     designation: "ADMIN"
  //   //   },
  //   // },
  //   // // { $match: { designation: "ADMIN" } },
  //   // {
  //   //   $graphLookup: {
  //   //     from: "employees",
  //   //     startWith: "$company",
  //   //     connectFromField: "_id",
  //   //     connectToField: "company",
  //   //     as: "reports",
  //   //     depthField: "level",
  //   //   },
  //   // },
  //   // {
  //   //   $addFields:{
  //   //     reports:{
  //   //       $map:{
  //   //         input:"$reports",
  //   //         as:"manager",
  //   //         in:{
  //   //           _id:"$$manager._id",
  //   //           firstname:"$$manager.firstname",
  //   //           lastname:"$$manager.lastname",
  //   //           designation:"$$manager.designation",
  //   //           reports:{
  //   //             $filter:{
  //   //               input:"$$manager.reports",
  //   //               as:"reportss",
  //   //               cond:{$eq:["$$reportss.designation","DEVELOPER"]}
  //   //             }
  //   //           }
  //   //         }
  //   //       }
  //   //     }
  //   //   }
  //   // },

  //   // {
  //   //   $project: {
  //   //     _id: 1,
  //   //     firstname: 1,
  //   //     lastname: 1,
  //   //     email: 1,
  //   //     designation: 1,
  //   //     company: 1,
  //   //     reports:1

  //   //   },
  //   // },

  //   {
  //     $match: {
  //       company: mongoose.Types.ObjectId.createFromHexString(company_id),
  //       designation: "ADMIN",
  //     },
  //   },
  //   {
  //     $graphLookup: {
  //       from: "employees",
  //       startWith: "$company",
  //       connectFromField: "_id",
  //       connectToField: "company",
  //       as: "reports",
  //       depthField: "level",

  //     },
  //   },
  //   {
  //     $addFields: {
  //       reports: {
  //         $map: {
  //           input: "$reports",
  //           as: "manager",
  //           in: {
  //             _id: "$$manager._id",
  //             firstname: "$$manager.firstname",
  //             lastname: "$$manager.lastname",
  //             designation: "$$manager.designation",
  //             company: "$$manager.company",
  //             reportsTo:"$$manager.reportsTo",
  //             reports:{
  //               $cond: { if: { $eq: ["$$manager.reportsTo", "$reports._id"] }, then: "", else: [] }
  //             }
  //             // reports: {
  //             //   $map:{
  //             //     input: "$$manager.reports",
  //             //     as: "emp",
  //             //     in: {
  //             //       _id: "$$emp._id",
  //             //       firstname: "$$emp.firstname",
  //             //       lastname: "$$emp.lastname",
  //             //       designation: "$$emp.designation",
  //             //       company: "$$emp.company",
  //             //       reportsTo:"$$emp.reportsTo",
  //             //       reports:{
  //             //         $filter: {
  //             //           input: "$$manager.reports",
  //             //           as: "reports",
  //             //           cond: { $eq: ["$$reports.designation", "DEVELOPER"] },
  //             //         },
  //             //       }
  //             //       }
  //             //   },

  //             // },
  //           },
  //         },
  //       },
  //     },
  //   },
  // ]);

  const result = Employee.aggregate([
    {
      $match: {
        company: mongoose.Types.ObjectId.createFromHexString(company_id),
        designation: "ADMIN",
      },
    },
    {
      $graphLookup: {
        from: "employees",
        startWith: "$company",
        connectFromField: "_id",
        connectToField: "company",
        as: "reports",
        depthField: "level",
        maxDepth: 10,
      },
    },
    // {
    //   $addFields: {
    //     reports: {
    //       $map: {
    //         input: "$reports",
    //         as: "manager",
    //         in: {
    //           _id: "$$manager._id",
    //           firstname: "$$manager.firstname",
    //           lastname: "$$manager.lastname",
    //           designation: "$$manager.designation",
    //           company: "$$manager.company",
    //           reports:"$$manager.reportsTo"
    //           // reports: {
    //           //   $filter: {
    //           //     input: "$reports",
    //           //     as: "subordinate",
    //           //     cond:{$eq:[ "$$subordinate._id" , "$$manager._id"]},
    //           //     // cond: { $eq: ["$$subordinate.reportsTo", "$$this._id"] },
    //           //   },
    //           // },
    //         },
    //       },
    //     },
    //   },
    // },
  ]);

  // const result1 = Employee.find({company:mongoose.Types.ObjectId.createFromHexString(company_id)})
  //                         .populate({path:'reportsTo',
  //                           populate:{
  //                             path:'reportsTo',
  //                             model:'Employee'
  //                           }
  //                         })

  // const result1 =  Employee.find({
  //   company: mongoose.Types.ObjectId.createFromHexString(company_id),
  // }).populate({
  //   path: "reportsTo",
  //   populate: {
  //     path: "reports",
  //     populate: {
  //       path: "reports",
  //       model: "Employee",
  //     },
  //   },
  // });

  const result2 = Employee.find({
    company: mongoose.Types.ObjectId.createFromHexString(company_id),
  })
    .populate({
      path: "reportsTo",
      select: "_id designation",
      populate: {
        path: "reportsTo",
        // select: "_id firstname lastname email designation company verified",
        select: "_id designation",

        populate: {
          path: "reportsTo",
          // select: "_id firstname lastname email designation company verified",
          select: "_id designation",
        },
        // model: "Employee",
      },
    })
    .select("-password");

  // const result3 = Employee.aggregate([
  //   {
  //     $match: {
  //       company: mongoose.Types.ObjectId.createFromHexString(company_id),
  //       designation: "ADMIN",
  //     },
  //   },
  //   // {
  //   //   $graphLookup: {
  //   //     from: "employees",
  //   //     startWith: "$_id",
  //   //     connectFromField: "reportsTo",
  //   //     connectToField: "reportsTo",
  //   //     as: "reportees",
  //   //     depthField: 'level',
  //   //     // maxDepth: 2,

  //   //   },
  //   // },
  //   {
  //     $graphLookup: {
  //       from: "employees",  // We are looking up in the "employees" collection
  //       startWith: "$_id",  // Start with the `_id` of the employee that matches the ADMIN
  //       connectFromField: "_id",  // We connect using the `_id` field in the source document
  //       connectToField: "reportsTo",  // We match to the `reportsTo` field in the target documents (employees reporting to)
  //       as: "reportees",  // Store the result in the "reportees" field
  //       depthField: "level",  // Track the level of each reportee (depth of hierarchy)
  //       maxDepth: 3,  // You can set a max depth for how many levels deep you want to traverse (optional)
  //     },
  //   },

  //   // {
  //   //   $graphLookup:{
  //   //     from:"employees",
  //   //     startWith:"$_id",
  //   //     connectFromField:"reportees",
  //   //     connectToField:"reportsTo",
  //   //     as:'reportees',
  //   //     depthField:'level'
  //   //   }
  //   // },

  //   // {
  //   //   $project: {
  //   //     _id: 1,
  //   //     firstname: 1,
  //   //     lastname: 1,
  //   //     designation: 1,
  //   //     email: 1,
  //   //     reportsTo: 1,
  //   //     reportees: {
  //   //       _id: 1,
  //   //       firstname: 1,
  //   //       lastname: 1,
  //   //       designation: 1,
  //   //       email: 1,
  //   //       reportsTo: 1,
  //   //       reportees: 1,
  //   //       level: 1,
  //   //     },
  //   //   },
  //   // },
  // ]);

  const result5 = Employee.aggregate([
    {
      $match: {
        company: mongoose.Types.ObjectId.createFromHexString(company_id),
        designation: "ADMIN", // We are looking for the ADMIN level employees
      },
    },
    {
      $graphLookup: {
        from: "employees", // The collection we want to lookup (the same "Employee" collection)
        startWith: "$_id", // Start from the "ADMIN" employee's _id
        connectFromField: "_id", // Connect by the employee's _id
        connectToField: "reportsTo", // Find the employee whose reportsTo matches the current employee's _id
        as: "reportees", // Store the result in the "reportees" field
        depthField: "level", // Keep track of the level of the employee in the hierarchy
        maxDepth: 5, // Adjust max depth to prevent deep recursion loops (optional)
      },
    },
    {
      $addFields: {
        reportees: {
          $map: {
            input: "$reportees", // Iterate through the "reportees"
            as: "reportee",
            in: {
              _id: "$$reportee._id",
              firstname: "$$reportee.firstname",
              lastname: "$$reportee.lastname",
              designation: "$$reportee.designation",
              company: "$$reportee.company",
              reportsTo: "$$reportee.reportsTo",
              level: "$$reportee.level",
              reportees: {
                // Get subordinates reporting to this specific employee
                $filter: {
                  input: "$reportees", // Filtering from the "reportees" array
                  as: "subordinate",
                  cond: { $eq: ["$$subordinate.reportsTo", "$$reportee._id"] }, // Ensure the filter matches reportees reporting to this employee
                },
              },
            },
          },
        },
      },
    },
    {
      $project: {
        _id: 1,
        firstname: 1,
        lastname: 1,
        designation: 1,
        company: 1,
        verified: 1,
        reportsTo: 1,
        reportees: 1, // Include the reportees
      },
    },
  ]);

  const result6 = Employee.aggregate([
    {
      $match: {
        company: mongoose.Types.ObjectId.createFromHexString(company_id),
        designation: "ADMIN",
      },
    },
    {
      $unionWith: {
        coll: "employees",
        pipeline: [
          {
            $match: {
              company: mongoose.Types.ObjectId.createFromHexString(company_id),
              reportsTo: { $exists: false },
            },
          },
        ],
      },
    },
    {
      $graphLookup: {
        from: "employees",
        startWith: "$_id",
        // startWith:{
        //   $cond: { if: { $not: ["$reportsTo"] }, then: "$_id", else: "$reportsTo" }
        // },
        // startWith: { $ifNull: ["$reportsTo", "$_id"] },
        connectFromField: "_id",
        connectToField: "reportsTo",
        as: "reportees",
        depthField: "level",
        maxDepth: 4,
      },
    },

    // {
    //   $project: {
    //     _id: 1,
    //     firstname: 1,
    //     lastname: 1,
    //     designation: 1,
    //     company: 1,
    //     verified: 1,
    //     reportees: {
    //       $map: {
    //         input: "$reportees",
    //         as: "reportee",
    //         in: {
    //           _id: "$$reportee._id",
    //           firstname: "$$reportee.firstname",
    //           lastname: "$$reportee.lastname",
    //           designation: "$$reportee.designation",
    //           company: "$$reportee.company",
    //           reportsTo: "$$reportee.reportsTo",
    //           level: "$$reportee.level",
    //           reportees: {
    //             $filter: {
    //               input: "$reportees",
    //               as: "subordinate",
    //               cond: { $eq: ["$$subordinate.reportsTo", "$$reportee._id"] },
    //             },
    //           },
    //         },
    //       },
    //     },
    //   },
    // },

    {
      $unwind: {
        path: "$reportees",
        preserveNullAndEmptyArrays: true,
      },
    },

    {
      $group: {
        _id: "$_id",
        firstname: { $first: "$firstname" },
        lastname: { $first: "$lastname" },
        designation: { $first: "$designation" },
        company: { $first: "$company" },
        verified: { $first: "$verified" },
        reportees: { $addToSet: "$reportees" },
      },
    },
    // {
    //   $project: {
    //     _id: 1,
    //     firstname: 1,
    //     lastname: 1,
    //     designation: 1,
    //     company: 1,
    //     verified: 1,
    //     // reportees: 1,
    //     reportees: {
    //       $map: {
    //         input: "$reportees",
    //         as: "reportee",
    //         in: {
    //           _id: "$$reportee._id",
    //           firstname: "$$reportee.firstname",
    //           lastname: "$$reportee.lastname",
    //           designation: "$$reportee.designation",
    //           company: "$$reportee.company",
    //           reportsTo: "$$reportee.reportsTo",
    //           level: "$$reportee.level",
    //           reportees: {
    //             $filter: {
    //               input: "$reportees",
    //               as: "subordinate",
    //               cond: { $eq: ["$$subordinate.reportsTo", "$$reportee._id"] },
    //             },
    //           },
    //         },
    //       },
    //     },
    //   },
    // },

    {
      $project: {
        _id: 1,
        firstname: 1,
        lastname: 1,
        designation: 1,
        company: 1,
        verified: 1,
        reportees: {
          $map: {
            // input: "$reportees",
            input: {
              $filter: {
                input: "$reportees",
                as: "reportee",
                cond: { $eq: ["$$reportee.level", 0] },
              },
            },
            as: "reportee",
            in: {
              _id: "$$reportee._id",
              firstname: "$$reportee.firstname",
              lastname: "$$reportee.lastname",
              designation: "$$reportee.designation",
              company: "$$reportee.company",
              reportsTo: "$$reportee.reportsTo",
              level: "$$reportee.level",
              // reportees: {

              //   $filter: {
              //     input: "$reportees",
              //     as: "subordinate",
              //     cond: { $eq: ["$$subordinate.reportsTo", "$$reportee._id"] },
              //   },
              // },
              reportees: {
                $map: {
                  input: {
                    $filter: {
                      input: "$reportees",
                      as: "subordinate",
                      cond: {
                        $eq: ["$$subordinate.reportsTo", "$$reportee._id"],
                      },
                    },
                  },
                  as: "subordinate",
                  in: {
                    _id: "$$subordinate._id",
                    firstname: "$$subordinate.firstname",
                    lastname: "$$subordinate.lastname",
                    designation: "$$subordinate.designation",
                    company: "$$subordinate.company",
                    reportsTo: "$$subordinate.reportsTo",
                    level: "$$subordinate.level",
                  },
                },
              },
            },
          },
        },
      },
    },
  ]);

  // const result3 =  Employee.aggregate([
  //           {
  //               $match:{company:mongoose.Types.ObjectId.createFromHexString(company_id)},

  //           },
  //           {
  //             $match:{designation:'ADMIN'}
  //           },
  //           {
  //               $graphLookup: {
  //                   from: "employees",
  //                   startWith: "$company",
  //                   connectFromField: "_id",
  //                   connectToField: "company",
  //                   as: "reports",
  //                   depthField: "level",
  //               }
  //           },
  //           // {
  //           //   $graphLookup: {
  //           //     from: "employees",
  //           //     startWith: { $arrayElemAt: ["$reports.reportsTo", 0] },
  //           //     connectFromField: "reportsTo",
  //           //     connectToField: "_id",
  //           //     as: "higherManagers"
  //           //   }
  //           // },
  //           {
  //             $project:{
  //               _id:1,
  //               firstname:1,
  //               lastname:1,
  //               designation:1,
  //               reports:{
  //                 _id:1,
  //                 firstname:1,
  //                 lastname:1,
  //                 designation:1
  //               }
  //             }
  //           }
  // ])

  //     const result: any = Employee.aggregate([
  //     {
  //         $match: {
  //             company: mongoose.Types.ObjectId.createFromHexString(company_id),
  //             designation: "ADMIN",
  //         },
  //     },
  //     {
  //         $graphLookup: {
  //             from: "employees",
  //             startWith: "$company",
  //             connectFromField: "_id",
  //             connectToField: "company",
  //             as: "reports",
  //             depthField: "level",
  //         },
  //     },
  //     {
  //         $addFields: {
  //             reports: {
  //                 $reduce: {
  //                     input: {
  //                         $filter: {
  //                             input: "$reports",
  //                             as: "manager",
  //                             cond: { $ne: ["$$manager.designation", "ADMIN"] }
  //                         }
  //                     },
  //                     initialValue: [],
  //                     in: {
  //                         $concatArrays: [
  //                             "$$value",
  //                             [
  //                                 {
  //                                     _id: "$$this.reportsTo",
  //                                     firstname: "$$this.firstname",
  //                                     lastname: "$$this.lastname",
  //                                     designation: "$$this.designation",
  //                                     company: "$$this.company",
  //                                     reportsTo: "$$this.reportsTo",
  //                                     reports: {
  //                                         $filter: {
  //                                             input: "$reports",
  //                                             as: "subordinate",
  //                                             cond: { $eq: ["$$subordinate.reportsTo", "$$this._id"] }
  //                                         }
  //                                     }
  //                                 }
  //                             ]
  //                         ]
  //                     }
  //                 }
  //             }
  //         },
  //     },
  // ]);

  return result6;
};

/**
 * Verify Employee Account
 *
 * @param token - the token to be used for verify account
 * @returns  - the result of the employee verify and update verified field in db
 */

const verifyEmployee = async (token: string) => {
  const employee: any = await Employee.findOne({ verificationToken: token });
  console.log(employee);
  // if (!employee.verified) {
  //     return null;
  // }

  // employee.verified = true;
  await Employee.updateOne(
    { verificationToken: token },
    { $set: { verified: true, verificationToken: null } }
  );
  // await Employee.
  // employee.verificationToken = null;
  // await employee.save();

  return employee;
};

/**
 * Update Employee Data
 *
 * @param id - the id of the employee to find the employee
 * @param data - the data to be updated in the employee
 * @returns  - the result of the employee updated
 */

const updateEmployee = (id: string, data: any) => {
  return Employee.findByIdAndUpdate(id, data, { new: true });
};

/**
 * Export data to a Excel file 
 * 
 * @returns - get all employee and export to excel file
 */
const exportExcelData = () => {
  return Employee.find({}).lean()
}

const exportPdf = () => {
  return Employee.find({}).lean()
}

export {
  signup,
  createEmployee,
  getAllEmployee,
  getEmployeeById,
  deleteEmployee,
  employeeHierarchy,
  verifyEmployee,
  updateEmployee,
  exportExcelData,
  exportPdf
};

//   console.log("result[0]:", result);
//   const hierarchy = createHierarchy(result[0]);
