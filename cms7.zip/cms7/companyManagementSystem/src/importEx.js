const path = require("path");
const { Worker, parentPort, workerData} = require("worker_threads");

const pathname = path.resolve(__dirname, "../dist/Controller/importexcel.js");
console.log("Worker path:", pathname);

try {
  const worker = new Worker(pathname);
  worker.on("message", (message) => {
    console.log("Message from worker:", message);
  });
} catch (error) {
  console.error("Worker initialization failed:", error.message);
}
