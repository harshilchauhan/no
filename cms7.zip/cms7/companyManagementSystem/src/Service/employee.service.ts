// const employeeDao = require('../DAO/employee.dao')
import * as employeeDao from "../DAO/employee.dao";

/**
 * Adds a new employee
 * @param  data - The employee data to be added.
 * @returns -The created employee object.
 */

const addEmployee = (data: any) => {
  return employeeDao.createEmployee(data);
};

/**
 * Registers a new employee
 * @param data - The registration data for the employee.
 * @returns -The registered employee object.
 */
const registerEmployee = (data: any) => {
  return employeeDao.signup(data);
};

/**
 * Get all employees
 * @param  filter_employee - The filter criteria for retrieving employees.
 * @returns  -An array of employee objects.
 */

const getAllEmployee = (filter_employee: any) => {
  return employeeDao.getAllEmployee(filter_employee);
};

/**
 * Get Employee by EmployeeId
 * @param  id - The Id of the employee.
 * @returns -The employee object or null if not found.
 */
const getEmployeeById = (id: any) => {
  return employeeDao.getEmployeeById(id);
};

/**
 * Delete Employee By EmployeeId
 * @param  id - The Id of the employee to be deleted.
 * @returns  -employee was successfully deleted
 */
const deleteEmployee = (id: string) => {
  return employeeDao.deleteEmployee(id);
};

/**
 * Retrieves the hierarchy of employees within a company.
 * @param  company_id - The Id of the company.
 * @returns  -An array representing the employee hierarchy.
 */

const employeeHierarchy = (company_id: any) => {
  return employeeDao.employeeHierarchy(company_id);
};

/**
 * Update Employee Data
 * @param  id - The Id of the employee to be updated.
 * @param  data - The new data for the employee.
 * @returns  -The updated employee object.
 */
const updateEmployeeData = (id: string, data: any) => {
  return employeeDao.updateEmployee(id, data);
};

/**
 * Verifies an employee using a token.
 * @param  token - The token used for verification.
 * @returns  The verification result or employee data.
 */

const verifyEmployee = (token: string) => {
  return employeeDao.verifyEmployee(token);
};

/**
 *
 * @returns The Employee Data export to excel file
 */
const exportExcel = () => {
  return employeeDao.exportExcelData();
};

const exportPdf = () => {
  return employeeDao.exportPdf();
};

// module.exports = { addEmployee, registerEmployee, getAllEmployee, getEmployeeById, deleteEmployee, employeeHierarchy, verifyEmployee,updateEmployeeData }

export {
  addEmployee,
  registerEmployee,
  getAllEmployee,
  getEmployeeById,
  deleteEmployee,
  employeeHierarchy,
  verifyEmployee,
  updateEmployeeData,
  exportExcel,
  exportPdf
};
