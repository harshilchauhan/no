[{
    "length" : 1,
    "result" : [
        {
            "_id": "671a107655e7cd31063d5da3",
            "firstname": "jugal",
            "lastname": "bardolia",
            "email": "j@gmail.com",
            "password": "$2b$10$z7ltSmSoTbBiKm56X7VJL.Q8imgTTdZbt0OcxQ6XCKEFiuBBRPAW2",
            "designation": "ADMIN",
            "company": "6719d226fa7fa2b56902c740",
            "verified": false,
            "reportsTo": [
                {
                    "_id": "671a0a7a4faee51732f1f945",
                    "firstname": "demo",
                    "lastname": "demo",
                    "designation": "REPORTING_MANAGER",
                    "company": "6719d226fa7fa2b56902c740",
                    "reportsTo": [
                        {
                            "_id": "671b3d3fafeebc15af2a4326",
                            "firstname": "jemin1",
                            "lastname": "molesalam",
                            "designation": "DEVELOPER",
                            "company": "6719d226fa7fa2b56902c740",
                            "reportsTo": []
                        },
                        {
                            "_id": "671f3e16cb644a63b026997b",
                            "firstname": "jugal1",
                            "lastname": "lotwala",
                            "designation": "DEVELOPER",
                            "company": "6719d226fa7fa2b56902c740",
                            "reportsTo": []
                        },
                        {
                            "_id": "6719e0d7bce127ac22d020f5",
                            "firstname": "harshil",
                            "lastname": "chauhan",
                            "designation": "DEVELOPER",
                            "company": "6719d226fa7fa2b56902c740",
                            "reportsTo": []
                        },
                        {
                            "_id": "671a133747cd2289d5fad71d",
                            "firstname": "test1",
                            "lastname": "test1",
                            "designation": "DEVELOPER",
                            "company": "6719d226fa7fa2b56902c740",
                            "reportsTo": []
                        },
                        {
                            "_id": "67207f8ac4dc2300af1b33ac",
                            "firstname": "paras",
                            "lastname": "godhani",
                            "designation": "DEVELOPER",
                            "company": "6719d226fa7fa2b56902c740",
                            "reportsTo": []
                        },
                    ]
                },
                {
                    "_id": "6729ba38f866cae7d3be6aab",
                    "firstname": "abc",
                    "lastname": "de",
                    "designation": "DEVELOPER",
                    "company": "6719d226fa7fa2b56902c740",
                    "reportsTo": []
                },
                {
                    "_id": "6728980315d74122269c902e",
                    "firstname": "demo",
                    "lastname": "abc",
                    "designation": "DEVELOPER",
                    "company": "6719d226fa7fa2b56902c740",
                    "reportsTo": []
                },
                
                
            ]
        }
    ]
}]