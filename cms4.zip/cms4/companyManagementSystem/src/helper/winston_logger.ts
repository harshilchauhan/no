// import winston, { createLogger, format, level, transports } from 'winston'
import expresswinston from 'express-winston'
// const logger = createLogger({
//         level:'info',
//         format:
//         format.combine(
//             format.timestamp({format:'YYYY-MM-DD HH:mm:ss'}),
//             format.printf(({timestamp,level,message})=>{
//                 return `${timestamp} [${level}] : ${message}`
//             })
//         ),
//         // format.json(),
        
//     })

// const logger = winston.createLogger({
//     transports: [
//       new winston.transports.Console(),
//       new winston.transports.File({ filename: 'error.log' })
//     ]
//   });


// const logger:any = createLogger({
//       transports: [
//         new winston.transports.Console({
//           level:"info",
//           }),
//           new winston.transports.File({filename:'error.log'}),
//       ],
//       format: winston.format.combine(
//           winston.format.colorize(),
//           winston.format.json(),
//           winston.format.prettyPrint()
//       )
//   })
// const { createLogger, format, transports } = require('winston');






import { createLogger, format, transports } from 'winston'



const logger  = createLogger({
transports:
    new transports.File({
    filename: './src/logs/error.log',
    format:format.combine(
        // format.colorize(),
        format.timestamp({format: 'MMM-DD-YYYY HH:mm:ss'}),
        format.align(),
        format.printf((info:any) => `${info.level}: ${[info.timestamp]}: ${info.message}`),
    )}),
});

  
export default logger