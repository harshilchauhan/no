import { AnySchema, ValidationError } from 'yup'
import { Request, Response, NextFunction, query } from 'express'

// const  ReqBodyValidate = (schema:AnySchema) => async(req:Request,res:Response,next:NextFunction) =>{
//     try {
//         await schema.validate({
//             body:req.body,
//             query:req.query,
//             params:req.params
//         })
//         next()    
//     } catch (error:any) {
//         return res.status(400).send(error.message)
//     }



// }


const ReqBodyValidate = (schema: AnySchema) => async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        await schema.validate(
            // { 
                 req.body, 
                // params: req.params 
            // }, 
            { abortEarly: false });
        next();
    } catch (error) {
        if (error instanceof ValidationError) {
            res.status(400).json({ message: "Validation error", errors: error.errors });
        } else {
            next(error);
        }
    }
};


const ReqParamValidate = (schema: AnySchema) => async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    // console.log("Validating params:", req.params);
    try {
        await schema.validate(req.params, { abortEarly: false });
        next();
    } catch (error) {
        // console.error("Validation error:", error); 
        if (error instanceof ValidationError) {
            res.status(400).json({ message: "Validation error", errors: error.errors });    
        } else {
            next(error);
        }
    }
};
const validateParams = (schema: AnySchema) => async (req: Request, res: Response, next: NextFunction): Promise<void>  => {
    try {
        // if (!req.params.id) {
        //     console.log("ID parameter is missing in request"); // Log for debugging
        //      res.status(400).json({ message: "Validation error", errors: ["ID parameter is required"] });
        //   }
      await schema.validate(req.params,{ abortEarly: false });
      next(); // continue if validation succeeds
    } catch (error) {
        if (error instanceof ValidationError) {
            res.status(400).json({ message: "Validation error", errors: error.errors });    
        } else {
            next(error);
        }
    }
  };

export  {ReqBodyValidate,ReqParamValidate,validateParams}
