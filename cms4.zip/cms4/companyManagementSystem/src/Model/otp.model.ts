import mongoose from "mongoose";
const otpSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: "Employee",
  },
  otp: {
    type: Number,
    required: true,
  },
  timestamp: {
    type: Date,
    default: Date.now,
    required: true,
    get: (timestamp: any) => timestamp.getTime(),
    set: (timestamp: any) => new Date(timestamp),
  },
});

export default mongoose.model("otp", otpSchema);
