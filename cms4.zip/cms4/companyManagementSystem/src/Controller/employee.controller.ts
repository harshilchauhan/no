import * as employeeService from "../Service/employee.service";
import Employee from "../Model/employee.model";
import {
  generateToken,
  generateRefreshToken,
  verifyToken,
} from "../Auth/jwt_helper";
import createError from "http-errors";
// const createError = require('http-errors')
import { sendVerificationMail, sendOtpVerify } from "../Auth/email_sender";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { Request, Response } from "express";
import dotenv from "dotenv";
dotenv.config();
import { CustomRequest } from "../types/types";
import logger from "../helper/winston_logger";
import xlsx from "xlsx";
import otpModel from "../Model/otp.model";
import { oneMinutevalidate, threeMinutevalidate } from "../Auth/otpValidate";
import ejs from "ejs";
import pdf from "html-pdf";
import path from "path";
import fs from "fs";
import puppeteer from "puppeteer";

const access_token_secret = process.env.access_token_secret as string;

/**
 * Create new Employee
 *
 * @param req -The request object containing the company data in the body.
 * @param res -The response object used to send a response back to the client.
 * @returns  - return new employee object
 */

const createEmployee = async (req: Request, res: Response) => {
  try {
    const custReq = req as CustomRequest;
    if (custReq.companyPayload?.designation !== "ADMIN") {
      logger.warn("access denied only admin can access this api");
      res.status(403).send("Access denied.");
      return;
    }
    //   console.log('payload:',custReq.companyPayload)
    const { firstname, lastname, email, password, designation, reportsTo } =
      req.body;
    const newEmployee = await employeeService.addEmployee({
      firstname,
      lastname,
      email,
      password,
      designation,
      reportsTo,
      company: custReq.companyPayload.company,
    });
    logger.info("new employee register successfully");
    res
      .status(201)
      .json({ newEmployee: newEmployee, message: "new employee created.." });
  } catch (error: any) {
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

// const registerEmployee = async(req:Request,res:Response)=>{
//     try {
//         const {firstname,lastname,email,password,company,designation} = req.body

//         const newRegisterEmployee = await employeeService.registerEmployee(
//                                     {firstname:firstname,lastname:lastname,email:email,password:password,company:company,designation:designation})

//         const payLoad = {id:newRegisterEmployee._id,email:email}
//         const verificationToken = await generateToken(payLoad)
//         const refreshToken = await generateRefreshToken(payLoad)
//         newRegisterEmployee.verificationToken = verificationToken;
//         await newRegisterEmployee.save()
//         const verificationLink = `http://localhost:3000/api/verify-account/${verificationToken}`

//         await sendVerificationMail(newRegisterEmployee.firstname,newRegisterEmployee.email,verificationLink)
//         res.status(200).json({newRegisterEmployee:newRegisterEmployee,refreshToken:refreshToken, message:'employee register successfully..'})
//     } catch (error:any) {
//         console.log(error.message)
//         res.status(500).json({message:'internal server error',error:error.message})
//     }
// }

/**
 * Register New Employee
 *
 * @param req -The request object containing the company data in the body.
 * @param res -The response object used to send a response back to the client.'
 * @returns -return employee register successfully and send verification email to the employee email.
 */
const registerEmployee = async (req: Request, res: Response) => {
  try {
    const { firstname, lastname, email, password, company, designation } =
      req.body;

    const emailExists = await Employee.findOne({ email: email });
    if (emailExists) throw new Error("email already exists..");
    const newRegisterEmployee = await employeeService.registerEmployee({
      firstname: firstname,
      lastname: lastname,
      email: email,
      password: password,
      company: company,
      designation: designation,
    });

    const payLoad = { id: newRegisterEmployee._id, email: email };
    const verificationToken = await generateToken(payLoad);
    const refreshToken = await generateRefreshToken(payLoad);
    newRegisterEmployee.verificationToken = verificationToken;
    await newRegisterEmployee.save();
    const verificationLink = `http://localhost:8888/api/verify-account/${newRegisterEmployee.verificationToken}`;

    await sendVerificationMail(
      newRegisterEmployee.firstname,
      newRegisterEmployee.email,
      verificationLink
    );
    logger.info(
      `employee registration  successfully.. account verification email is sent to your ${email} address `
    );
    res.status(201).json({
      message: `employee registration  successfully.. account verification email is sent to your ${email} address `,
    });
  } catch (error: any) {
    // console.log(error.message)
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

/**
 * Verify Employee Account
 *
 * @param req - The request object containing the token
 * @param res - The response object used to send a response back to the client.
 * @returns - return employee verified successfully
 */

const getverifyUser = async (req: Request, res: Response) => {
  try {
    const { token } = req.params;
    // const findUserId = await Employee.findById({_id:user_id})
    // console.log(findUserId)

    const employee = await employeeService.verifyEmployee(token);
    // if(!findUserId){
    // res.status(404).json({message:'user not found'})
    // }
    // await Employee.updateOne({_id:user_id},{$set:{verified:true}})
    // res.status(200).json({message:'user verify successfully'})
    res.render("email-verified");
  } catch (error: any) {
    console.log(error.message);
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

const comparePassword = async (
  enterpassword: string,
  storepassword: string
) => {
  try {
    const isValid = await bcrypt.compare(enterpassword, storepassword);
    // console.log(storepassword);
    // console.log("enter pass:", enterpassword);
    // console.log(isValid);
    return isValid;
  } catch (error) {
    throw error;
  }
};

/**
 * Login Employee
 *
 * @param req - The request object containing the email,password
 * @param res - The response object used to send a response back to the client.
 * @returns -return login succesffuly
 */

const signin = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const user = await Employee.findOne({ email: email });
    // console.log(user);
    if (!user) {
      throw createError.NotFound(`${email} is not register..`);
    }
    const isMatch = await comparePassword(password, user.password);
    // console.log(isMatch);
    // const isMatch = await user.isValidPassword(password)
    if (!isMatch) {
      throw createError.NotFound("password not match.");
    }
    const payLoad = {
      id: user.id,
      email: user.email,
      designation: user.designation,
      company: user.company,
    };
    const refreshPayLoad = { id: user.id };
    const accessToken = await generateToken(payLoad);
    const refreshToken = await generateRefreshToken(refreshPayLoad);
    logger.info("login successfully");
    res.status(200).json({
      token: accessToken,
      refreshToken: refreshToken,
      message: "login successfully..",
    });
  } catch (error: any) {
    console.log(error.message);
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

/**
 * Get Employee Details
 *
 * @param req - The request object containing the filter_employee to filter Employee Data
 * @param res - The response object used to send a response back to the client.
 * @returns -return  filter employee data
 */

const getEmployee = async (req: Request, res: Response) => {
  try {
    const result = await employeeService.getAllEmployee(
      req.query.filter_employee
    );
    // console.log(req.query.keyword)
    res.status(200).json({ length: result.length, employee: result });
  } catch (error: any) {
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

/*const getAllEmployee = async (data: any) => {
    const filters: any = {};

    
    for (const key in data) {
        if (data.hasOwnProperty(key)) {
            
            if (key.startsWith("filter_")) {
            
                const fieldName = key.replace("filter_", "");  
                filters[fieldName] = data[key];
            }
            
        }
    }

    
    const pipeline: any[] = [
        {
            $match: filters 
        },
        
    ];

    
    return Employee.aggregate(pipeline);
}



const getEmployee = async (req: Request, res: Response) => {
    try {
        // Call the service function and pass the query parameters from the request
        const result = await employeeService.getAllEmployee(req.query);

        // Return the response with filtered results
        res.status(200).json({
            length: result.length,
            employee: result
        });
    } catch (error: any) {
        res.status(500).json({ message: 'Internal server error', error: error.message });
    }
}
*/

/**
 * Get Employee By Id
 *
 * @param req - The request object containing the query parameters of the employeeid
 * @param res - The response object find employee by id
 * @returns - The result will be a single employee object
 */

const getEmployeeById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    console.log(id);
    if (!id) {
      res
        .status(400)
        .json({ message: "Validation error", errors: ["ID is required"] });
      return;
    }
    const result = await employeeService.getEmployeeById(id);
    res.status(200).json({ employee: result });
  } catch (error: any) {
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

/**
 * Delete Employee
 *
 * @param req - The request object containing the query parameters of the employeeid
 * @param res - The response object find employee by id and delete employee
 * @returns  - The Result is employee deleted successfully
 */

const deleteEmployee = async (req: Request, res: Response) => {
  try {
    const custReq = req as CustomRequest;
    if (custReq.companyPayload?.designation !== "ADMIN") {
      res.status(403).send("Access denied.");
      return;
    }
    const Id = req.params.id;
    const result = await employeeService.deleteEmployee(Id);
    logger.info("employee deleted.");
    res.status(200).json({ message: "employee deleted." });
  } catch (error: any) {
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

/**
 * Get Employee Hierarchy
 *
 * @param req - The request object containing the query parameters of the companyId
 * @param res - The response object find employee by company id
 * @returns - The result return all employeeHierarchy company wise
 */

const employeeHierarchy = async (req: Request, res: Response) => {
  try {
    const { company_id } = req.params;
    // console.log(company_id)
    const result = await employeeService.employeeHierarchy(company_id);
    // console.log(result)
    // const filterResult = result.filter((data:any)=>data.company===company_id)
    res.status(200).json({ length: result.length, result: result });
  } catch (error: any) {
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

// const verifyAccount = async(req:Request,res:Response)=>{

//     const token = req.params.token
//     console.log(token)
//     const custReq = req as CustomRequest
//     if (custReq.companyPayload.designation !== 'ADMIN') {
//          res.status(403).send('Access denied.');
//          return
//       }
//     try {
//         const employee = await employeeService.verifyEmployee(token)
//         console.log('service employee:',employee)
//         if(!employee) {
//              res.status(400).json({ message: 'Invalid token or account already verified.' });
//              return
//         }
//         res.status(200).json({ message: 'Account verified successfully!', employee });
//         // res.render('email-verified')

//     } catch (error:any) {
//         res.status(500).json({message:'internal server error',error:error.message})
//     }
// }

// const updateEmployee = async(req,res)=>{
//     try {
//         const id = req.params.id
//         console.log(id)
//         const employee = await Employee.findById(id);
//         console.log(employee)
//         if(req.companyPayload.id !== id && employee.reportsTo !==req.companyPayload.id){
//             return res.status(403).json({ error: "Unauthorized to update this employee." });
//         }
//         const updateBody = req.body
//         const result = await employeeService.updateEmployeeData(employee.id,updateBody)
//         res.status(200).json({updateCompany:result,message:'employee detail updated..'})
//     } catch (error) {
//         res.status(500).json({message:'internal server error',error:error.message})
//     }
// }

/**
 * Get Refresh Token
 *
 * @param req - The request object is empty
 * @param res - The response object send refresh token to client
 * @returns - The resulr will be return refrsh token in object
 */

const refreshToken = (req: Request, res: Response) => {
  try {
    const custReq = req as CustomRequest;
    console.log(custReq.refreshPayload);
    const payLoad = { id: custReq.refreshPayload.id };
    console.log(payLoad);
    const newAccessToken = generateToken({ id: payLoad });
    res.status(200).json({ accessToken: newAccessToken });
  } catch (error: any) {
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};

/**
 * Update Password of the particular employee
 *
 * @param req - The request object is contain token,password,confirm_password
 * @param res - The response object return password successfully.
 * @returns - The result will be return password updated successfully
 */

const updatePassword = async (req: Request, res: Response) => {
  const token = req.params.token;
  console.log(token);
  const { password, confirm_password } = req.body;
  try {
    const decoded: any = jwt.verify(token, access_token_secret);
    const userId = decoded.id;
    if (password !== confirm_password) {
      logger.error("confirm password is not match.");
      res.status(400).json({ message: "confirm password is not match" });
      return;
    }
    const user = await Employee.findById(userId);
    console.log(user);
    if (!user) {
      logger.error("user not exists");
      res.status(400).json({ message: "User not exists!" });
      return;
    }
    if (user.verified != true) {
      logger.error("user is not verified.");
      res.status(400).json({ message: "User is not verified.." });
      return;
    }
    // const encryptedPassword = await bcrypt.hash(confirm_password, 10);
    const encryptedPassword = confirm_password;
    user.password = encryptedPassword;
    await user.save();
    logger.info("password updated successfully");
    res.status(200).json({ message: "password updated successfully.." });
  } catch (error: any) {
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};
/**
 * Update Employee Data
 *
 * @param req - The Request object is contain employeeid,employee data
 * @param res - The response object return employee update successfully
 * @returns  - The result will be return employee updated successfully
 */

const updateEmployee = async (req: Request, res: Response) => {
  try {
    const custReq = req as CustomRequest;
    if (custReq.companyPayload.designation !== "REPORTING_MANAGER") {
      logger.warn("not authority to update data");
      res.status(403).json({ message: "not authority to update data " });
      return;
    }
    const { id } = req.params;
    const employeeToUpdate = await Employee.findById(id);
    const {
      firstname,
      lastname,
      email,
      password,
      designation,
      company,
      reportsTo,
    } = req.body;
    const encryptedPassword = await bcrypt.hash(password, 10);
    // console.log(encryptedPassword);
    const result = await Employee.findByIdAndUpdate(
      employeeToUpdate,
      {
        firstname,
        lastname,
        email,
        password: encryptedPassword,
        designation,
        company,
        reportsTo,
      },
      { new: true }
    );
    logger.info("password updated.");
    res.status(200).json({ message: "data updated.. ", result: result });
    return;
  } catch (error: any) {
    console.log(error.message);
    logger.error(error.message);
    res
      .status(500)
      .json({ message: "internal server error", error: error.message });
  }
};
/**
 *
 * @param req
 * @param res - The response object return export file succesfully
 * @returns - The result excel file download succesfully
 */

const excelData = async (req: Request, res: Response) => {
  try {
    // const getData = await Employee.find({}).lean();
    const getData = await employeeService.exportExcel();
    if (!getData.length) {
      res.status(404).json({ message: "No data found to export." });
    }
    const modifiedData = getData.map((item) => ({
      // ...item,
      Employee_Id: item._id.toString(),
      First_Name: item.firstname,
      Last_Name: item.lastname,
      Email: item.email,
      Password: item.password,
      Designation: item.designation,
      Company: item.company ? item.company.toString() : "",
      ReportsTo: item.reportsTo ? item.reportsTo.toString() : "",
    }));

    // const headers = Object.keys(modifiedData[0]);
    // console.log('header:',headers)

    // const userFriendlyHeaders: any = {
    //   _id: "Employee_Id",
    //   firstname: "First_Name",
    //   lastname: "Last_Name",
    //   email: "Email",
    //   password: "Password",
    //   designation: "Designation",
    //   company: "Company",
    //   reportsTo: "Reports_To",
    // };
    // const headerRow = headers.map((key) => userFriendlyHeaders[key]);
    // console.log(headerRow)

    // // Convert data into an array of arrays for the worksheet
    // const dataRows = modifiedData.map((item: any) =>
    //   headers.map((key) => item[key])
    // );

    // // Combine headers and data
    // const worksheetData = [headerRow, ...dataRows];

    const workBook = xlsx.utils.book_new();
    const workSheet = xlsx.utils.json_to_sheet(modifiedData);
    xlsx.utils.book_append_sheet(workBook, workSheet, "employee");
    const timestamp = Date.now();
    // console.log(timestamp);
    const filename = `employee_data_${timestamp}.xlsx`;
    const filePathName = path.join(
      __dirname,
      "../public/exportExcel/",
      filename
    );
    // console.log(filePathName);
    xlsx.writeFile(workBook, filePathName);
    res.status(200).json({ message: "file export success." });
  } catch (error: any) {
    res
      .status(500)
      .json({ message: "Internal server error.", error: error.message });
  }
};

const generateOtp = async () => {
  return Math.floor(1000 + Math.random() * 9000);
};

const sendOtp = async (req: Request, res: Response) => {
  try {
    const { email } = req.body;

    const userData = await Employee.findOne({ email });

    if (!userData) {
      res.status(400).json({ msg: "email does not exists." });
      return;
    }

    if (userData?.verified == true) {
      res.status(400).json({ msg: "email is already verified." });
      return;
    }
    const curr_date = new Date();

    const otp = await generateOtp();

    const oldOtpData = await otpModel.findOne({ user_id: userData._id });

    if (oldOtpData) {
      const sendnextOtp = await oneMinutevalidate(oldOtpData.timestamp);
      if (!sendnextOtp) {
        res.status(400).json({ msg: "please try after 1 minute." });
        return;
      }
    }

    const otp_update = await otpModel.findOneAndUpdate(
      { user_id: userData._id },
      { otp: otp, timestamp: new Date(curr_date.getTime()) },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    // const enter_otp = new otpModel({
    //   user_id: userData?._id,
    //   otp: otp,
    // });
    // await enter_otp.save();
    // const msg = `<p> Hello <b>${userData?.firstname}</b>,</br><h4> </h4></p>`;
    // const verificationLink = `http://localhost:8888/api/verify-account/${newRegisterEmployee.verificationToken}`;
    await sendOtpVerify(userData?.firstname, userData?.email, otp_update.otp);
    res.status(200).json({
      success: true,
      msg: "Otp has been sent to your email please check! ",
    });
    return;
  } catch (error: any) {
    res.status(400).json({ success: false, msg: error.message });
  }
};

const verifyOtp = async (req: Request, res: Response) => {
  try {
    const { user_id, otp } = req.body;
    const otpData = await otpModel.findOne({ user_id, otp });

    if (!otpData) {
      res.status(400).json({ msg: "Invalid otp." });
      return;
    }

    const isOtpExpired = await threeMinutevalidate(otpData?.timestamp);

    if (isOtpExpired) {
      res.status(400).json({ msg: "your OTP is expired!" });
      return;
    }

    await Employee.findByIdAndUpdate(
      { _id: user_id },
      { $set: { verified: true } }
    );

    res
      .status(200)
      .json({ success: true, msg: "account verified successfully!" });
  } catch (error: any) {
    res.status(400).json({ success: false, msg: error.message });
    return;
  }
};

const exportPdf = async (req: Request, res: Response) => {
  try {
    // const employee = await Employee.find({});
    // const data = { employee: employee };
    // const filePathName = path.resolve(__dirname, "../views/employeeTable.ejs");
    // console.log(filePathName);
    // const htmlString = fs.readFileSync(filePathName).toString();
    // console.log("html string : ", htmlString);
    // let options: any = {
    //   format: "Letter",
    // };
    // const ejsData = ejs.render(htmlString, data);
    // console.log("ejs data : ", ejsData);
    // pdf.create(ejsData, options).toFile("employee.pdf", (err, res) => {
    //   if (err) console.log(err.message);
    //   console.log("file generated..");
    // });

    const employee = await employeeService.exportPdf();
    const data = { employee: employee };
    const filePathName = path.resolve(__dirname, "../views/employeeTable.ejs");
    const htmlString = fs.readFileSync(filePathName).toString();
    // console.log("html string :", htmlString);
    const ejsData = ejs.render(htmlString, data);
    // console.log("ejs data :", ejsData);

    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.setContent(ejsData);
    const timestamp = Date.now();
    const filename = `employee_data_${timestamp}.pdf`;
    const filePath = path.join(__dirname, "../public/upload/", filename);
    const pdfOptions: any = {
      path: filePath,
      format: "Letter",
      printBackground: true,
      displayHeaderFooter: true,
      // headerTemplate: `
      //   <div style="width: 100%; text-align: center; font-size: 20px; color: gray;">
      //     <span>Employee Report</span>
      //   </div>`,
      footerTemplate: `
        <div style="width: 100%; text-align: center; font-size: 10px; color: gray;">
          Page <span class="pageNumber"></span> of <span class="totalPages"></span>
        </div>`,
      margin: {
        top: "20px",
        bottom: "40px",
        right: "20px",
        left: "20px",
      },
    };
    await page.pdf(pdfOptions);
    await browser.close();
    res.status(200).json({ msg: "pdf generated successfully!" });
  } catch (error: any) {
    res.status(400).json({ msg: error.message });
    return;
  }
};

// const importExcel = async (req: Request, res: Response) => {
//   // const filename = req.
//   const filePathName = path.resolve(
//     __dirname,
//     "/employee_data_Fri Nov 15 2024 10:17:40 GMT+0530 (India Standard Time).xlsx"
//   );
//   const workBook = xlsx.readFile(filePathName);
//   const sheet: any = workBook.SheetNames;
//   const data = xlsx.utils.sheet_to_json(sheet[0]);
//   console.log("data: ", data);
// };

// const BATCH_SIZE = 500;

// async function batchInsert(collectionName: string, data: any[], batchSize: number) {
//   const collection = db.collection(collectionName);
//   for (let i = 0; i < data.length; i += batchSize) {
//     const batch = data.slice(i, i + batchSize);
//     await collection.insertMany(batch, { ordered: false });
//   }
// }
const CHUNK_SIZE = 1000;

const importExcel = async (req: Request, res: Response) => {
  // req.setTimeout(300000);
  const filename: any = req.file?.originalname;
  // console.log("filename :", filename);
  const filePathName = path.join(__dirname, "../public/upload/", filename);
  // console.log(filePathName);
  // const insertPromises = [];
  try {
    // const workBook = xlsx.readFile(filePathName);
    // const sheetName = workBook.SheetNames[0];

    // const data: any = xlsx.utils.sheet_to_json(workBook.Sheets[sheetName]);
    // // console.log("data:", data);

    // const employee_response = [];
    // for (var i = 0; i < data.length; i++) {
    //   employee_response.push({
    //     id: data[i].Employee_Id,
    //     firstname: data[i].First_Name,
    //     lastname: data[i].Last_Name,
    //     email: data[i].Email,
    //     password: data[i].Password,
    //     designation: data[i].Designation,
    //     company: data[i].Company,
    //     reportsTo: data[i].ReportsTo ? data[i].ReportsTo : null,
    //   });
    //   await Employee.insertMany(employee_response);
    // }
    // console.log(data);

    // // console.log("employe resp:", employee_response);

    // console.log(`Worker ${process.pid} completed import`);

    // res.status(200).json({ success: true, msg: "excel imported" });

    const workBook = xlsx.readFile(filePathName);
    const sheetName = workBook.SheetNames[0];

    const data: any[] = xlsx.utils.sheet_to_json(workBook.Sheets[sheetName]);
    const employee_response = [];
    for (let i = 0; i < data.length; i += CHUNK_SIZE) {
      const chunk = data.slice(i, i + CHUNK_SIZE).map((record) => ({
        id: record.Employee_Id,
        firstname: record.First_Name,
        lastname: record.Last_Name,
        email: record.Email,
        password: record.Password,
        designation: record.Designation,
        company: record.Company,
        reportsTo: record.ReportsTo || null,
      }));
      // console.log('chunk:',chunk)

      // insertPromises.push(Employee.insertMany(chunk));
      // await Employee.insertMany(chunk);
      employee_response.push(Employee.insertMany(chunk))
    }
    // await Promise.all(insertPromises);
    
    // for (let i = 0; i < data.length; i += CHUNK_SIZE) {
    //   const chunk = data.slice(i, i + CHUNK_SIZE).map((record) => {
    //     let companyId = record.Company;

    //     // console.log("cid:", companyId);

    //     // Convert company ID if it's a valid ObjectId or handle invalid cases
    //     if (typeof companyId === "number") {
    //       companyId = companyId.toString();
    //     }
    //     if (mongoose.Types.ObjectId.isValid(companyId)) {
    //       companyId = mongoose.Types.ObjectId.createFromHexString(companyId);

    //     }

    //     return {
    //       id: record.Employee_Id,
    //       firstname: record.First_Name,
    //       lastname: record.Last_Name,
    //       email: record.Email,
    //       password: record.Password,
    //       designation: record.Designation,
    //       company: record.Company || null,
    //       reportsTo: record.ReportsTo || null,
    //     };
    //   });

    //   await Employee.insertMany(chunk);
    // }

    console.log(`Worker ${process.pid} completed import`);
    res.status(200).json({ success: true, msg: "Excel imported" });
  } catch (error: any) {
    // console.log("error:", error.message);
    // if (error.code === 11000) {
    //   res
    //     .status(400)
    //     .json({ error: "Duplicate key error" });
    // } else {
    //   res.status(400).json({ error: "An unexpected error occurred." });
    // }
    res.status(500).json({ error: error.message });
    process.send && process.send({ status: "error", error: error.message });
  }
};

export {
  createEmployee,
  registerEmployee,
  signin,
  getEmployee,
  getEmployeeById,
  deleteEmployee,
  employeeHierarchy,
  // verifyAccount,
  updateEmployee,
  refreshToken,
  updatePassword,
  getverifyUser,
  excelData,
  sendOtp,
  verifyOtp,
  exportPdf,
  importExcel,
};
