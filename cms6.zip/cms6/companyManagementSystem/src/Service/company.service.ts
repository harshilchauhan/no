// const companyDao = require('../DAO/company.dao')
import * as companyDao from "../DAO/company.dao";

/**
 * Registers a new company.
 *
 * @param {string} data - The data required to register the company.
 * @returns {Promise} - A promise that resolves when the company is registered.
 */

const registerCompany = (data: string) => {
  return companyDao.companyRegister(data);
};

/**
 * Updates an existing company.
 *
 * @param {any} id - The ID of the company to be updated.
 * @param {any} data - The new data to update the company with.
 * @returns {Promise} - A promise that resolves when the company is updated.
 */
const updateCompany = (id: any, data: any) => {
  return companyDao.updateCompany(id, data);
};

// module.exports={
//     registerCompany,
//     updateCompany
// }
export { updateCompany, registerCompany };

// how to implement the above code in jsdoc
