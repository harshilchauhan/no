// "firstName": "user first name",  // required, string
// "lastName": "user last name", // required, string
// "email": "user email address", // required, unique, string
// "password": "account password",  // required, string
// "designation": "employee designation",  // required, string, enum:[ “ADMIN”, “REPORTING_MANAGER”, “DEVELOPER”]
// "company": "reference of company collection", // required, ObjectId
// "verified": "account is verified or not", // boolean, default: false
// "reportsTo": “a reference to employee schema”, // ObjectId

// const mongoose = require('mongoose')
// const joi = require('joi')
import mongoose from "mongoose";
import joi, { Err } from "joi";
// const bcrypt = require('bcrypt')
import bcrypt from "bcrypt";

const employeeSchema = new mongoose.Schema(
  {
    firstname: { type: String, required: true },
    lastname: { type: String, required: true },
    email: {
      type: String,
      required: true,
      // unique: true,
      lowercase: true,
      validate: {
        validator: function (v: any) {
          return /^\S+@\S+\.\S+$/.test(v);
        },
        message: (props: any) => `${props.value} is not a valid email!`,
      },
    },
    password: { type: String, required: true },
    designation: {
      type: String,
      required: true,
      enum: ["ADMIN", "REPORTING_MANAGER", "DEVELOPER"],
      default: "DEVELOPER",
    },
    company: {
      // required: true,
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
    },
    verified: { type: Boolean, default: false },
    reportsTo: { type: mongoose.Schema.Types.ObjectId, ref: "Employee" },
    verificationToken: { type: String },
  },
  { versionKey: false }
);

employeeSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    try {
      const salt = await bcrypt.genSalt(10);
      this.password = await bcrypt.hash(this.password, salt);
    } catch (error) {
      console.log(error);
      next(this.errors);
    }
  }
  next();
});

// employeeSchema.methods.isValidPassword = async function (candidatePassword) {
//     try {
//         const isMatch = await bcrypt.compare(candidatePassword,this.password)
//         console.log('pass:',this.password);
//     console.log('candi pass:',candidatePassword);
//     return isMatch
//     } catch (error) {
//         throw error
//     }
// }

// module.exports = mongoose.model('Employee',employeeSchema)
export default mongoose.model("Employee", employeeSchema);



