// import { parentPort, workerData } from 'worker_threads';
const { parentPort, isMainThread, workerData } = require("worker_threads");
// import xlsx from 'xlsx';
const xlsx = require("xlsx");
// import Employee from "../Model/employee.model";
// const Employee = require("../Model/employee.model");
import Employee from "../Model/employee.model";
// const Employee = require("../Model/employee.model");

const chunk_size = 200;

async function processExcel(fileBuffer: Buffer) {
  try {
    // const workBook = xlsx.read(fileBuffer);
    // const workBook = xlsx.readFile(filePath);
    const workBook = xlsx.read(fileBuffer, { type: "buffer" });
    if (!workBook.SheetNames || workBook.SheetNames.length === 0) {
      throw new Error("No sheets found in the uploaded file");
    }
    // console.log("workbook:", workBook)
    // console.log("Worker received filePath:", workerData.fileBuffer);
    // if (!workerData.filePath) {
    //   parentPort?.postMessage({ success: false, error: "File path is undefined." });

    // }

    const sheetName = workBook.SheetNames[0];
    console.log("sheet name ", sheetName);
    const data = xlsx.utils.sheet_to_json(workBook.Sheets[sheetName]);
    // console.log("data", data);
    const employee_response = [];
    for (let i = 0; i < data.length; i += chunk_size) {
      const sliceData = data.slice(i, i + chunk_size);
      const chunk = sliceData.map((record: any) => ({
        id: record.Employee_Id,
        firstname: record.First_Name,
        lastname: record.Last_Name,
        email: record.Email,
        password: record.Password,
        designation: record.Designation,
        company: record.Company,
        reportsTo: record.ReportsTo || null,
      }));

      employee_response.push(Employee.insertMany(chunk));
    }

    parentPort?.postMessage({ success: true });
  } catch (error: any) {
    console.log("error:", error.message);
    parentPort?.postMessage({ success: false, error: error.message });
  }
}

// if (!isMainThread) {
// const { fileBuffer } = workerData;
processExcel(workerData.fileBuffer);
// }
