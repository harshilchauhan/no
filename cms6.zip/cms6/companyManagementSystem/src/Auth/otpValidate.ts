const oneMinutevalidate = (otpTime: any) => {
  try {
    console.log("timestamp:", otpTime);
    const curr_datetime = new Date();
    var diffrenceValue = (otpTime - curr_datetime.getTime()) / 1000;
    diffrenceValue /= 60;
    console.log("expiry minute:", Math.abs(diffrenceValue));

    if (Math.abs(diffrenceValue) > 1) {
      return true;
    }
    return false;
  } catch (error) {
    console.log(error);
  }
};


const threeMinutevalidate = (otpTime: any) => {
  try {
    console.log("timestamp:", otpTime);
    const curr_datetime = new Date();
    var diffrenceValue = (otpTime - curr_datetime.getTime()) / 1000;
    diffrenceValue /= 60;
    console.log("expiry minute:", Math.abs(diffrenceValue));

    if (Math.abs(diffrenceValue) > 3) {
      return true;
    }
    return false;
  } catch (error) {
    console.log(error);
  }
};

export  {oneMinutevalidate,threeMinutevalidate};
