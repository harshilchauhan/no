const Company = require('../Model/company.model')

const companyRegister = (data)=>{
    const newCompany = new Company(data)
    return newCompany.save()
}

const updateCompany=(id,data)=>{
    return Company.findByIdAndUpdate(id,data,{new:true,})
}

module.exports = {
    companyRegister,
    updateCompany
}