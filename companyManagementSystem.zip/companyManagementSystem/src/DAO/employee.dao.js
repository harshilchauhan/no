const Employee = require('../Model/employee.model')
const Company = require('../Model/company.model')

const createEmployee = (data) => {
    const newEmployee = new Employee(data)
    return newEmployee.save()
}

const signup = (data) => {
    // try {
    //     const bodyData = req.body
    //     const newEmployee = new Employee(bodyData)
    //     const saveEmployee = await newEmployee.save()

    //     res.send({ registerEmployee: saveEmployee, message: 'employee register..' })
    // } catch (error) {
    //     res.send(error.message)
    // }  
    const existingCompany = Company.findById(data.company)
    if (!existingCompany) {
        throw new Error('company does not exist..');
    }
    const registerEmployee = new Employee(data)
    return registerEmployee.save()

}

const getAllEmployee = (data) => {
    return Employee.find(data)

}
// return Employee.find().where('firstname').equals(data)

const getEmployeeById = (id) => {
    return Employee.findById(id)
}

const deleteEmployee = (id) => {
    return Employee.findByIdAndDelete(id)
}

const employeeHierarchy = () => {
    return Employee.find().populate('company', 'name email -_id')
}


const verifyEmployee = async (token) => {
    const employee = await Employee.findOne({ verificationToken: token });
    if (!employee.verified) {
        return null;
    }
    employee.verified = true;
    employee.verificationToken = null;
    await employee.save();

    return employee;
};


module.exports = { signup, createEmployee, getAllEmployee, getEmployeeById, deleteEmployee, employeeHierarchy, verifyEmployee }