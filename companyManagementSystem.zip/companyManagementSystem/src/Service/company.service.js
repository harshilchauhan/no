const companyDao = require('../DAO/company.dao')


const registerCompany = (data)=>{
    return companyDao.companyRegister(data)
}   

const updateCompany = (id,data) =>{
    return companyDao.updateCompany(id,data)
}

module.exports={
    registerCompany,
    updateCompany
}