const bcrypt = require('bcrypt')

const comparePassword = async(enterpassword,storepassword)=>{
    try {
        return await bcrypt.compare(enterpassword,storepassword)
    } catch (error) {
        throw error
    }
}

module.exports = comparePassword