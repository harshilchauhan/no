const jwt = require('jsonwebtoken')
require('dotenv').config()
const createError = require('http-errors')

const generateToken = (data) => {
    return jwt.sign(data, process.env.access_token_secret,{ expiresIn: '30m' })
}

const verifyToken = (req, res, next) => {
    const authorization = req.headers['authorization']
    if (!authorization) return next(createError.NotFound('token not found'))

    const authHeader = req.headers['authorization']
    const bearertoken = authHeader.split(' ')
    const token = bearertoken[1]
    if(!token) return next(createError.Unauthorized())
    jwt.verify(token, process.env.access_token_secret, (err, payload) => {
        if (err) return res.status(401).json({message:'token is expire..'})
        req.companyPayload = payload
        next()
    })
}

module.exports = { generateToken, verifyToken }