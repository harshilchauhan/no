const nodemailer = require('nodemailer')
const {google}=require('googleapis')
require('dotenv').config()


const createTransporter = async ()=>{
    const oAuth2Client=new google.auth.OAuth2(process.env.Client_Id,process.env.Client_secret,process.env.Redirect_uri)
    oAuth2Client.setCredentials({refresh_token:process.env.Refresh_token})
    const accesstoken = await oAuth2Client.getAccessToken()
    // console.log(accesstoken)
    const transport = nodemailer.createTransport({
        service:'gmail',
        auth:{
            type:'OAuth2',
            user:'harshil.webosmotic@gmail.com',
            clientId:process.env.Client_Id,
            clientSecret:process.env.Client_secret,
            refreshToken:process.env.Refresh_token,
            accessToken:accesstoken.token

        }

    })
    return transport
}


const sendVerificationMail = async(name,email,verificationLink)=>{
    try {
        let transporter = await createTransporter();
            const option = { 
                from:'harshilchauhan157@gmail.com',
                to:email,
                subject:'Verification email',
                text:`Hello ${name}  `,
                html:'<p>Hello '+name+' please verify your account using this link to <a href="'+verificationLink+'"> verify</a> </p>',
                }
        await transporter.sendMail(option,function(err) {
            console.log('email sent')
            if (err){
            console.log(err)
            }
        })

    } catch (error) {
        console.log(error);
    }
}
// sendVerificationMail().then(result=>{
//     console.log('email sent',result);
    
// }).catch(err=>{
//     console.log(err.message);
// })


module.exports = {sendVerificationMail}