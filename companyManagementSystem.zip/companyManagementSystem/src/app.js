
// import express from "express"
const express = require('express')
const app = express()

// import employeerouter from './Route/employee.route.js'
const employeerouter = require('./Route/employee.route')

// import companyrouter from './Route/company.route.js'
const companyrouter = require('./Route/company.route')
// import createError from 'http-errors'
const createError = require('http-errors')
const db = require('./config/db.js')
require('dotenv').config()
const port = process.env.PORT

app.use('/api',employeerouter)
app.use('/api',companyrouter)

// app.set("views", path.join(__dirname, "views"));
// app.set('view engine', 'ejs');


// app.use(async (req, res, next) => {
//     // const error= new Error("not found")
//     // error.status =404
//     next(createError.NotFound())
// })

// app.use((err: { status: any; message: any }, req: any, res: { status: (arg0: any) => void; send: (arg0: { error: { status: any; message: any } }) => void }, next: any) => {
//     res.status(err.status || 500)
//     res.send({
//         error: {
//             status: err.status || 500,
//             message: err.message
//         }
//     })

// })

app.listen(port,()=>{
    console.log(`server run.. at ${port} `)
})