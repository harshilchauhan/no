const companyService = require('../Service/company.service')

const registerCompany = async(req,res)=>{
    try {
        const bodyData = req.body
        const newCompany = await companyService.registerCompany(bodyData)
        res.status(200).json({newCompany:newCompany,message:'new company register..'})
    } catch (error) {
        console.log(error.message)
        res.status(500).json({message:'internal server error'})
    }
}

const updateCompany = async(req,res)=>{
    try {
        if (req.companyPayload.designation !== 'ADMIN') {
            return res.status(403).send('Access denied.');
          }
        const Id = req.params.id
        const updateBody = req.body
        const result = await companyService.updateCompany(Id,updateBody)
        res.status(200).json({updateCompany:result,message:'company detail updated..'})
    } catch (error) {
        res.status(500).json({message:'internal server error',error:error.message})
    }
}

module.exports = {registerCompany,updateCompany}