const express=require('express')
const router = express.Router()
router.use(express.json())
const companyController = require('../Controller/company.controller')
const {verifyToken} = require('../Auth/jwt_helper')

router.post('/newcompany',companyController.registerCompany)
router.put('/company/:id',verifyToken,companyController.updateCompany)
router.patch('/company/:id',verifyToken,companyController.updateCompany)

module.exports = router