const express=require('express')
const router = express.Router()
router.use(express.json())
const employeeController = require('../Controller/employee.controller')
const {verifyToken} = require('../Auth/jwt_helper')





router.post('/sign-up',employeeController.registerEmployee)
router.post('/sign-in',employeeController.signin)
router.post('/employee',verifyToken,employeeController.createEmployee)
router.get('/employee',employeeController.getEmployee)
router.get('/employee/:id',employeeController.getEmployeeById)
router.delete('/employee/:id',verifyToken,employeeController.deleteEmployee)
router.get('/employee+hierarchy',employeeController.employeeHierarchy)
router.get('/verify-account/:token',verifyToken,employeeController.verifyAccount)


module.exports = router





















/*

app.put('/api/company', authenticateJWT, async (req, res) => {
    if (req.user.designation !== 'ADMIN') {
        return res.sendStatus(403);
    }

    try {
        const company = await Company.findByIdAndUpdate(req.body.id, req.body, { new: true });
        res.json(company);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update Company API (Admin Only, PATCH)
app.patch('/api/company', authenticateJWT, async (req, res) => {
    if (req.user.designation !== 'ADMIN') {
        return res.sendStatus(403);
    }

    try {
        const company = await Company.findByIdAndUpdate(req.body.id, req.body, { new: true });
        res.json(company);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
*/






